library(shinydashboard)
library(shiny)
library(data.table)
library(doFuture)
library(future)
library(foreach)
library(igraph)
library(openxlsx)
library(parallel)
#library(batl)
#library(batl_test)
library(shinyWidgets)
library(DT)
library(shinyjs)
library(tools)
library(progressr)
#library(R.utils)
#source("gui_functions_tabs_1_2_3_4_mod_08212021.R")

source("/var/www/compLiMet/public_html/batl_test/batl_test/R/build_library.R")
source("/var/www/compLiMet/public_html/batl_test/batl_test/R/data-srm_tc.R")
source("/var/www/compLiMet/public_html/batl_test/batl_test/R/deartifact_export_peaks.R")
source("/var/www/compLiMet/public_html/batl_test/batl_test/R/deartifact_import_peaks.R")
source("/var/www/compLiMet/public_html/batl_test/batl_test/R/deartifact_peaks.R")
source("/var/www/compLiMet/public_html/batl_test/batl_test/R/deartifact_peaks_helper.R")
source("/var/www/compLiMet/public_html/batl_test/batl_test/R/decision_map_dup.R")
source("/var/www/compLiMet/public_html/batl_test/batl_test/R/decision_map_nodup.R")
source("/var/www/compLiMet/public_html/batl_test/batl_test/R/decision_mwbm.R")
source("/var/www/compLiMet/public_html/batl_test/batl_test/R/gui_functions_tabs_1_2_3_4.R")
source("/var/www/compLiMet/public_html/batl_test/batl_test/R/map_library_features_is.R")
source("/var/www/compLiMet/public_html/batl_test/batl_test/R/multiple_assignments.R")
source("/var/www/compLiMet/public_html/batl_test/batl_test/R/nb_append_library.R")
source("/var/www/compLiMet/public_html/batl_test/batl_test/R/nb_build_model.R")
source("/var/www/compLiMet/public_html/batl_test/batl_test/R/nb_build_model_helpers.R")
source("/var/www/compLiMet/public_html/batl_test/batl_test/R/nb_build_model_shiny.R")
source("/var/www/compLiMet/public_html/batl_test/batl_test/R/nb_export_labelled_file.R")
source("/var/www/compLiMet/public_html/batl_test/batl_test/R/nb_export_library.R")
source("/var/www/compLiMet/public_html/batl_test/batl_test/R/nb_export_model.R")
source("/var/www/compLiMet/public_html/batl_test/batl_test/R/nb_import_labelled_file.R")
source("/var/www/compLiMet/public_html/batl_test/batl_test/R/nb_import_labelled_file_list.R")
source("/var/www/compLiMet/public_html/batl_test/batl_test/R/nb_import_library.R")
source("/var/www/compLiMet/public_html/batl_test/batl_test/R/nb_import_model.R")
source("/var/www/compLiMet/public_html/batl_test/batl_test/R/nb_label_peaks.R")
source("/var/www/compLiMet/public_html/batl_test/batl_test/R/nb_label_peaks_helper.R")
source("/var/www/compLiMet/public_html/batl_test/batl_test/R/nb_model_scores.R")
source("/var/www/compLiMet/public_html/batl_test/batl_test/R/nb_scatterplot.R")
source("/var/www/compLiMet/public_html/batl_test/batl_test/R/spreadsheet_mismatches.R")
source("/var/www/compLiMet/public_html/batl_test/batl_test/R/utility_accuracy.R")


useShinyjs(rmd = TRUE)

#options(shiny.maxRequestSize=30*1024^2)


ui <- dashboardPage(skin="black",
                    dashboardHeader(title = "BATL"), 
                    dashboardSidebar(div(style = "margin:30px;,margin-right:1000px;",actionButton("homeb",label="",icon=icon("home")))),
                    dashboardBody(shinyjs::useShinyjs(),
                                  fluidRow(height = 20000,
                                           tabsetPanel(type = "tabs",id = "tbs",
                                                       tabPanel("Instructions ",value="tab_6",column(width = 8,height = 50000,
                                                                                           box(id="cqf", height = 50000, width = 2000,source("help.R")$value                    
                                                                                               
                                                                                           ))),
                                                       
                                                       tabPanel("1. Create Training Set",value="tab_2",column(width = 8,height = 50000,
                                                                                                box(id="cts", height = 50000, width = 2000,source("create_training_set.R")$value
                                                               
                                                       ))),#tabpanel1
                                                       tabPanel("2. Build BATL model",value="tab_3",column(width = 8,height = 50000,
                                                                                  box(id="bbm", height = 50000, width = 2000,source("build_batl_model.R")$value
                                                       
                                                       ))),#tabpanel2
                                                       tabPanel("3. Annotate peaks",value="tab_4",column(width = 8,height = 50000,
                                                                                box(id="ap", height = 50000, width = 2000,source("annotate_peaks.R")$valu
                                                       
                                                       ))),#tabpanel3
                                                       
                                                       tabPanel("About",value="tab_5",column(width = 8,height = 50000,
                                                                                           box(id="cqf", height = 50000, width = 2000, source("about.R")$value                     
                                                                                               
                                                                                           )))
                                                       
                                           ),#tabpanelset
                                          
                                           
                                  ),
                                  
                                  tags$head(tags$style(HTML(
                                    '.main-header .logo,.myClass { 
        font-size: 20px;
        font-weight: 900;
        line-height: 50px;
        text-align: left;
        font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
        padding: 0 15px;
        overflow: hidden;
        color: black;
      }
    '))),
                                  tags$script(HTML('
      $(document).ready(function() {
        $("header").find("nav").append(\'<span class="myClass"> BATL: Bayesian annotations for targeted lipidomics </span>\');
      })
     ')),
                                  tags$head(
                                    tags$style(HTML(".skin-black .main-sidebar {background-color:  white;}"))
                                  )
                                  
                                  
                                  
                    )
                    
)



## Server logic
server <- function(input, output, session) {
    options(shiny.maxRequestSize=20000*1024^2)

    removeTab1 <- function() {
      
      removeUI(
        selector = "#input_file_conversion_confirm_vendor *",
        multiple = TRUE,
        immediate = TRUE
      )
     removeUI(
        selector = "#convert_input_files *",
        multiple = TRUE,
        immediate = TRUE
      )

     removeUI(
        selector = "#input_file_conversion_downloader *",
        multiple = TRUE,

        immediate = TRUE
      )

     removeUI(
        selector = "#lipid_identifier_instructions *",
        multiple = TRUE,
        immediate = TRUE
      )  
    }
        

  # INITIALIZATION ----------------------------------------------------------
  ## Reactive values (0L, 1L or 2L+) for conditionally displaying UI elements
  affirm <- reactiveValues(
    file_conversion_message = 0L,
    reveal_vendor_features  = 0L,
    annotate_peak_message = 0L
  )

  ## Reactive values to store all training set information
  training <- reactiveValues(
    vendor = "MultiQuant (SCIEX)",
    all_standards = NULL,
    output = NULL
  )

   tmpfiles_rs <- reactiveValues(tmpfilename = NULL)

  ## Reactive values to store all features from the UI
  features <- reactiveValues(
    core = NULL,          # stores all core features from the labelled files
    core_training = NULL, # stores updated core features to create training set
    custom = NULL,        # stores all custom features from the labelled files
    needs_normalization = c(
      "Relative retention time",
      "Subtracted retention time",
      "Relative area",
      "Relative height"
    )
  )

  ## Reactive values to store all model information
  model <- reactiveValues(
    folds = 100000L,
    decision = "MWBM",
    tolerance = 0,
    parallel_cores = 1L,
    exhaustive = FALSE,
    full_output = FALSE,
    output = NULL
  )

  ## Reactive values to store all relevant parameters for labelling peak files
  label <- reactiveValues(
    exceptions = c(            # default Mass.Info rows to ignore. DO NOT CHANGE
      "ADC",
      "TIC",
      "AAO Companion App. - ADD, Pressure (Pump1)"
    ),
    component_name = NULL,
    label = NULL,
    vendor = "MultiQuant (SCIEX)",
    output = NULL
  )

  ## Reactive values to store error-checking messages
  message <- reactiveValues(
    input_file_conversion_sanitize  = 0L,
    files_for_training_set_sanitize = NULL,
    custom_features_sanitize = NULL,
    reference_component = NULL,
    upload_model = 0L,
    annotate_file_sanitize = 0L,
    check_unlabelled = 0L,
    check_component = 0L,
    columns_sanitize = 0L
  )

 

  # Reactive to load and convert format =================================
  convert_input_file_conversion <- reactive({
    #showModal(modalDialog(paste("HELLO1",nffn,tmpfiles_rs$tmpfilename,input$input_file_conversion_confirm_vendor,training$vendor, getwd())))
    training$output <- convert_to_batl_format(
      tmpfiles_rs$tmpfilename,
      training$vendor,
      TRUE
    )
  })



        observeEvent(input$input_file_conversion,{

      
      removeUI(
        selector = "#input_file_conversion_confirm_vendor *",
        multiple = TRUE,
        immediate = TRUE
      )
     removeUI(
        selector = "#convert_input_files *",
        multiple = TRUE,
        immediate = TRUE
      )

     removeUI(
        selector = "#input_file_conversion_downloader *",
        multiple = TRUE,

        immediate = TRUE
      )

     removeUI(
        selector = "#lipid_identifier_instructions *",
        multiple = TRUE,
        immediate = TRUE
      )  

          
          date <- as.POSIXct(Sys.time(), format = "%m/%d/%Y %H:%M:%S")
          ts <- format(date, format = "%m%d%Y%H%M%S")

          #showModal(modalDialog(paste("HELLO")))

          if (is.null(input$input_file_conversion)){
             return()
          }else{
              nf <- gsub(".*/","",input$input_file_conversion$datapath)
              #showModal(modalDialog(paste("HEY THERE",nf,input$input_file_conversion$datapath)))
              nf <- gsub(".*\\.",paste(ts,".",sep=""),nf)
              nffn <- paste("/var/www/compLiMet/public_html/batl_test2/tmp",nf,sep="/")
              file.copy(input$input_file_conversion$datapath,nffn, overwrite = TRUE)
              tmpfiles_rs$tmpfilename <- nffn
         }


          # TAB 1 - CONVERTING VENDOR TO BATL-SPECIFIC FORMAT -----------------------
  # Reactive to error-check upload format =================================
  sanitize_input_file_conversion <- reactive({
    req(input$input_file_conversion)
    message$input_file_conversion_sanitize <- sanitize_vendor_format(
      tmpfiles_rs$tmpfilename
    )
  })

  # Reactive to predict vendor format =================================
  predict_input_file_conversion <- reactive({
    req(input$input_file_conversion)
    training$vendor <- predict_vendor_format(
      nffn
    )
  })



      ## Output: Error > 0L . No error == 0L.
    message$input_file_conversion_sanitize <- sanitize_input_file_conversion()
    #showModal(modalDialog(paste("HELLO THERE",message$input_file_conversion_sanitize)))
    
    ## File upload error: wrong file extension
    if (message$input_file_conversion_sanitize == 1L) {
        validate(
          need(
            message$input_file_conversion_sanitize == 0L,
            showModal(modalDialog("Uploaded file or files in .zip must end with .txt, .csv, .tsv, or .xlsx extension."))
          )
        )
        removeTab1()
    }
    ## File upload error: zip file contains data from different vendors
    else if (message$input_file_conversion_sanitize == 2L) {
        validate(
          need(
            message$input_file_conversion_sanitize == 0L,
            showModal(modalDialog("Uploaded files in .zip must come from the same vendor software program."))
          )
        )
        removeTab1()
    }
    ## (Partly) sanitized input file
    else  if (message$input_file_conversion_sanitize == 0L) {
      ## Predict the file format vendor and delete following UI if applicable
      training$vendor <- predict_input_file_conversion()
      removeTab1()
      affirm$file_conversion_message <- 0L

      ## File upload error: file format not recognized or incorrect
      if (length(training$vendor) == 0) {
          validate(
            need(
              length(training$vendor) != 0L,
              showModal(modalDialog("Uploaded file is not a valid SRM/MRM peak quantification file and/or the format is not supported."))
              )
          )
          removeTab1()
      }
      ## Completely sanitized file leads to radio buttons to confirm vendor format
      else {

        removeTab1()
        
        insertUI(
          selector = "#tab_1_placeholder_1",
          where = "beforeEnd",
          ui = mainPanel(
            div(
              radioButtons(
                "input_file_conversion_confirm_vendor",
                "Please confirm the format of the SRM/MRM peak quantification files:",
                choiceNames = list(
                  "MultiQuant (SCIEX)",
                  "MassHunter (Agilent)",
                  "MassLynx (Waters)",
                  HTML("Different format? <a href = 'mailto:jchitpin069@uottawa.ca'>Contact us.</a>")
                ),
                choiceValues = list(
                  "MultiQuant (SCIEX)",
                  "MassHunter (Agilent)",
                  "MassLynx (Waters)",
                  "Different format? Contact us"
                ),
                selected = training$vendor
              )
            ),
            id = "input_file_conversion_confirm_vendor"
          )
        )

         # Reactive to confirm necessary columns for successful file conversion =================================
  sanitize_input_file_columns <- reactive({

    
    message$input_file_column_sanitize <- sanitize_input_columns(
      tmpfiles_rs$tmpfilename,
      training$vendor
    )

  })



 ## Output: Error > 0L . No error == 0L.
    message$input_file_columns_sanitize <- sanitize_input_file_columns()
    
    ## File upload error: this error should never trigger for MultiQuant
    if (message$input_file_columns_sanitize == 1L) {
        validate(
          need(
            message$input_file_columns_sanitize == 0L,
            showModal(modalDialog(paste(
              "Invalid MultiQuant file. Must contain the following columns:",
              "Sample Index, Sample Name, Index, Mass Info, Component Name,",
              "and Retention Time."))
            )
          )
        )
        removeTab1()
    }
    ## File upload error: this error may occur for MassHunter files
    else if (message$input_file_columns_sanitize == 2L) {
        validate(
          need(
            message$input_file_columns_sanitize == 0L,
            showModal(modalDialog(paste(
              "Invalid MassHunter file. Must contain the following columns",
              "in the 2nd row header:",
              " Name, Transition, RT."))
            )  
          )
        )
        removeTab1()
    }
    ## File upload error: this error may occur for MassLynx files
    else if (message$input_file_columns_sanitize == 3L) {
        validate(
          need(
            message$input_file_columns_sanitize == 0L,
            showModal(modalDialog(paste(
              "Invalid MassLynx file. Must contain the following columns",
              "under each 'compound' table:",
              "<1st column empty>, #, Sample Text, Quan Trace."))
            )
            
          )
        )
        removeTab1()
    }
    ## No error: 
    else {
  
    removeUI(
      selector = "div:has(> #convert_input_files *)",
      multiple = TRUE,
      immediate = TRUE
    )

    removeUI(
      selector = "div:has(> #input_file_conversion_downloader *)",
      multiple = TRUE,
      immediate = TRUE
    )


    removeUI(
      selector = "div:has(> #lipid_identifier_instructions *)",
      multiple = TRUE,
      immediate = TRUE
    )

      insertUI(
        selector = "#tab_1_placeholder_2",
        where = "beforeEnd",
        ui = mainPanel(
          div(
            h3("Step 2"),
            actionButton(
              "convert_input_files",
              "Click here to convert your quantification files."
            ),
            id = "convert_input_files"
          )
        )
      )



   
    }














      }


    }




      })

      
  observeEvent(input$convert_input_files, {
  ## Remove downloader UI if applicable
    removeUI(
      selector = "#input_file_conversion_downloader",
      multiple = TRUE,
      immediate = TRUE
    )

    removeUI(
      selector = "#lipid_identifier_instructions",
      multiple = TRUE,
      immediate = TRUE
    )



    ## Convert files
    training$output <- convert_input_file_conversion()
    
    ## Reveal downloader UI
    insertUI(
      selector = "#tab_1_placeholder_3",
      where = "beforeEnd",
      ui = mainPanel(
        div(
          br(),
          downloadButton(
            "input_file_conversion_downloader",
            "Click here to download your converted files."
          )
        ),
        id = "input_file_conversion_downloader"
      )
    )
affirm$file_conversion_message <- 1L
    if (affirm$file_conversion_message == 1L) {
      ## Reveal instructions UI
      insertUI(
        selector = "#tab_1_placeholder_4",
        where = "beforeEnd",
        ui = mainPanel(
          div(
            br(),
            h3("Step 3"),
            p(
              paste(
                "Your files have been converted to the BATL-specific format.",
                "Please assign lipid identities to the last column of your",
                "downloaded file(s) under the"
              ),
              strong("Lipid_identifier"),
              paste(
                "column.",
                "Then proceed to Tab 2."
              )
            )
          ),
          id = "lipid_identifier_instructions"
        )
      )
    }

    
      
  })

  
  # Handler to download converted files =================================
  output$input_file_conversion_downloader <- downloadHandler(
    
    filename = function() {
      gsub(".xlsx", ".txt", paste0("BATL_converted", "_", gsub(".*/","",tmpfiles_rs$tmpfilename)))
    },
    content = function(connection) {
      # Unzip files if necessary and get all file names
      filenames <- unzip_files(tmpfiles_rs$tmpfilename)

      ## Get rid of starting './' in the filenames
      filenames <- gsub(".*//", "", filenames)
      filenames <- paste0("BATL_converted", "_", gsub(".*/","",filenames))
      
      ## Replace .xlsx with .txt
      filenames <- gsub(".xlsx", ".txt", filenames)

      ## Export converted quantification files
      if (length(filenames) > 1) {
        tmpdir <- "/var/www/compLiMet/public_html/batl_test2/tmp"
        setwd("/var/www/compLiMet/public_html/batl_test2/tmp")
        for (i in seq_along(filenames)) {
          nb_export_labelled_file(training$output[[i]], filenames[i])
        }
        zip(zipfile = connection, files = filenames)
      } else {
        nb_export_labelled_file(training$output[[1]], connection)
      }
      affirm$file_conversion_message <- affirm$file_conversion_message + 1L
    }
  )


  # TAB 2 - LOADING AND CONSTRUCTING THE TRAINING SET -----------------------
  # Reactive to error-check upload format =================================
  tmpfiles_rs1 <- reactiveValues(tmpfilename = NULL)

  sanitize_input_file <- reactive({
    req(input$files_for_training_set)
    message$input_file_conversion_sanitize <- sanitize_training_inputs(
      tmpfiles_rs1$tmpfilename
    )
  })

  # Reactive to get core features for the given vendor for radio buttons =================================
  get_core_features <- reactive({
    req(input$files_for_training_set)
    features$core <- list_core_features(
      tmpfiles_rs1$tmpfilename
    )
  })

  # Reactive to get custom features for the given file(s) =================================
  get_custom_features <- reactive({
    req(input$files_for_training_set)
    features$custom <- list_custom_features(
      tmpfiles_rs1$tmpfilename
    )
  })

  # Reactive to error-check custom features =================================
  sanitize_custom_features <- reactive({
    req(input$files_for_training_set, input$custom_features)
    message$custom_features_sanitize <- sanitize_custom_feature(
      tmpfiles_rs1$tmpfilename, input$custom_features
    )
  })


  # Reactive to output all valid lipid identifiers for the reference standard =================================
  get_reference_standards <- reactive({
    if (message$files_for_training_set_sanitize == 0L) {
      training$all_standards <- permissible_reference_standard(
        tmpfiles_rs1$tmpfilename
      )
    }
  })

  # Observe vendor file upload =================================
  observeEvent(input$files_for_training_set,{

    #reset("files_for_training_set")
    #tmpfiles_rs1$tmpfilename <- NULL
    
   removeUI(
      selector = "#core_features",
      multiple = TRUE,
      immediate = TRUE
    )
    removeUI(
      selector = "#custom_features",
      multiple = TRUE,
      immediate = TRUE
    )
    removeUI(
      selector = "#create_training",
      multiple = TRUE,
      immediate = TRUE
    )
    removeUI(
      selector = "#download_training",
      multiple = TRUE,
      immediate = TRUE
    )  
    removeUI(
      selector = "#build_model",
      multiple = TRUE,
      immediate = TRUE
    )  


    date1 <- as.POSIXct(Sys.time(), format = "%m/%d/%Y %H:%M:%S")
    ts1 <- format(date1, format = "%m%d%Y%H%M%S")

 
    if (is.null(input$files_for_training_set)){
        return()
    }else{
            nf1 <- gsub(".*/","",input$files_for_training_set$datapath)
            
            nf1 <- gsub(".*\\.",paste(ts1,".",sep=""),nf1)
            nffn1 <- paste("/var/www/compLiMet/public_html/batl_test2/tmp",nf1,sep="/")
            file.copy(input$files_for_training_set$datapath,nffn1, overwrite = TRUE)
            tmpfiles_rs1$tmpfilename <- nffn1
            #showModal(modalDialog(paste("HEY THERE",nf1,input$input_file_conversion$datapath)))
    }


    ## Remove subsequent UI if necessary
   # removeUI(
    #  selector = "#core_features",
    #  multiple = TRUE,
     # immediate = TRUE
    #)
    #removeUI(
    #  selector = "#custom_features",
    # multiple = TRUE,
    #  immediate = TRUE
    #)
    #removeUI(
    #  selector = "#create_training",
    #  multiple = TRUE,
    #  immediate = TRUE
    #)
    #removeUI(
    #  selector = "#download_training",
    #  multiple = TRUE,
    #  immediate = TRUE
    #)

    ## Output: Error > 0L . No error == 0L.
    message$files_for_training_set_sanitize <- sanitize_input_file()
    #message(message$files_for_training_set_sanitize) # print debugging - JC
  
     
    
    ## File upload error: wrong file extension
    if (message$files_for_training_set_sanitize == 1L) {
        validate(
          need(
            message$files_for_training_set_sanitize_message == 0L,
            showModal(modalDialog("Uploaded file or files in .zip must end with a .txt extension.")))
        )
    removeUI(
      selector = "#core_features",
      multiple = TRUE,
      immediate = TRUE
    )
    removeUI(
      selector = "#custom_features",
      multiple = TRUE,
      immediate = TRUE
    )
    removeUI(
      selector = "#create_training",
      multiple = TRUE,
      immediate = TRUE
    )
    removeUI(
      selector = "#download_training",
      multiple = TRUE,
      immediate = TRUE
    )  

    removeUI(
      selector = "#build_model",
      multiple = TRUE,
      immediate = TRUE
    )  

    }
    ## File upload error: necessary column headers not provided in uploaded file
    else if (message$files_for_training_set_sanitize == 2L) {
        validate(
          need(
            message$files_for_training_set_sanitize_1 == 0L,
            showModal(modalDialog(paste(
              "The following columns must be present in your uploaded files:\n",
              "Sample.Index, Sample.Name, Index, Mass.Info,",
              "Component.Name, Retention.Time or RT, and either",
              "Lipid_identifier, or Lipid_identifier_MWBM."))
            )
          )
        )

    removeUI(
      selector = "#core_features",
      multiple = TRUE,
      immediate = TRUE
    )
    removeUI(
      selector = "#custom_features",
      multiple = TRUE,
      immediate = TRUE
    )
    removeUI(
      selector = "#create_training",
      multiple = TRUE,
      immediate = TRUE
    )
    removeUI(
      selector = "#download_training",
      multiple = TRUE,
      immediate = TRUE
    )  
    removeUI(
      selector = "#build_model",
      multiple = TRUE,
      immediate = TRUE
    )  

    }
    ## File upload error: file must have a Retention Time/RT column
    else if (message$files_for_training_set_sanitize == 3L) {
        validate(
          need(
            message$files_for_training_set_sanitize_message_1 == 0L,
            showModal(modalDialog(paste(
              "The following column must be present in your uploaded files:\n",
              "Retention.Time (MultiQuant), or RT (MassHunter/MassLynx)."))
            )
          )
        )
    removeUI(
      selector = "#core_features",
      multiple = TRUE,
      immediate = TRUE
    )
    removeUI(
      selector = "#custom_features",
      multiple = TRUE,
      immediate = TRUE
    )
    removeUI(
      selector = "#create_training",
      multiple = TRUE,
      immediate = TRUE
    )
    removeUI(
      selector = "#download_training",
      multiple = TRUE,
      immediate = TRUE
    )  

    removeUI(
      selector = "#build_model",
      multiple = TRUE,
      immediate = TRUE
    )  

    }
    ## File upload error: files must have a column of lipid identifiers
    else if (message$files_for_training_set_sanitize == 4L) {
        validate(
          need(
            message$files_for_training_set_sanitize_message_1 == 0L,
            paste(
              showModal(modalDialog("The following column must be present in your uploaded files:\n",
              "Lipid_identifier, or Lipid_identifier_MWBM. Please ensure your",
              "SRM/MRM quantification files are labelled."))      
            )
          )
        )
     removeUI(
      selector = "#core_features",
      multiple = TRUE,
      immediate = TRUE
    )
    removeUI(
      selector = "#custom_features",
      multiple = TRUE,
      immediate = TRUE
    )
    removeUI(
      selector = "#create_training",
      multiple = TRUE,
      immediate = TRUE
    )
    removeUI(
      selector = "#download_training",
      multiple = TRUE,
      immediate = TRUE
    )  

    removeUI(
      selector = "#build_model",
      multiple = TRUE,
      immediate = TRUE
    )  

    }
    ## File upload error: Lipid_identifier column is all NA
    else if (message$files_for_training_set_sanitize == 5L) {
        validate(
          need(
            message$files_for_training_set_sanitize_message_1 == 0L,
            showModal(modalDialog(paste(
              "The Lipid_identifier/Lipid_identifier_column has not been",
              "filled out."))
            )
          )
        )
    removeUI(
      selector = "#core_features",
      multiple = TRUE,
      immediate = TRUE
    )
    removeUI(
      selector = "#custom_features",
      multiple = TRUE,
      immediate = TRUE
    )
    removeUI(
      selector = "#create_training",
      multiple = TRUE,
      immediate = TRUE
    )
    removeUI(
      selector = "#download_training",
      multiple = TRUE,
      immediate = TRUE
    )  

    removeUI(
      selector = "#build_model",
      multiple = TRUE,
      immediate = TRUE
    )  

    }
    ## File upload error: all files must have the same number of columns/names
    else if (message$files_for_training_set_sanitize == 6L) {
        validate(
          need(
            message$files_for_training_set_sanitize_message_1 == 0L,
            showModal(modalDialog(paste(
              "All files must contain the exact same number of columns with",
              "the exact same names."))
            )
          )
        )
         removeUI(
      selector = "#core_features",
      multiple = TRUE,
      immediate = TRUE
    )
    removeUI(
      selector = "#custom_features",
      multiple = TRUE,
      immediate = TRUE
    )
    removeUI(
      selector = "#create_training",
      multiple = TRUE,
      immediate = TRUE
    )
    removeUI(
      selector = "#download_training",
      multiple = TRUE,
      immediate = TRUE
    )  

    removeUI(
      selector = "#build_model",
      multiple = TRUE,
      immediate = TRUE
    )  

    }else{
     
      if (message$files_for_training_set_sanitize == 0L) {
        affirm$reveal_vendor_features <- 1L
      } else {
        affirm$reveal_vendor_features <- 0L
      }

      if (affirm$reveal_vendor_features == 1L) {
      
      ## Group check box of core BATL features
      features$core <- get_core_features()
      
      insertUI(
        selector = "#tab_2_placeholder_2",
        where = "beforeEnd",
        ui = mainPanel(
          div(
            h3("Step 2"),
            checkboxGroupInput(
              "core_features",
              "Confirm the peak features for lipid identification:",
              inline = FALSE,
              choices = features$core,
              selected = features$core
            ),
            id = "core_features"
          )
        )
      )
      
      ## Drop down menu of custom BATL features
      features$custom <- get_custom_features()
      
      insertUI(
        selector = "#tab_2_placeholder_3",
        where = "beforeEnd",
        ui = mainPanel(
          div(
            selectInput(
              "custom_features",
              "Custom peak features (advanced usage):",
              choices = features$custom,
              multiple = TRUE,
              selected = NULL
            ),
            id = "custom_features"
          )
        )
      )

     insertUI(
      selector = "#tab_2_placeholder_5",
      where = "beforeEnd",
      ui = mainPanel(
        div(
          h3("Step 3"),
          actionButton(
            "create_training",
            "Click here to create your training set."
          ),
          id = "create_training"
        )
      )
    )
   # Observe user feature selection and error-check =================================
  message_custom_feature_warning <- reactive({

    ## Reactive to determine if the custom features are valid numerics
    message$custom_features_sanitize <- sanitize_custom_features()
    if (message$custom_features_sanitize == 1L) {
      validate(
        need(
          message$custom_features_sanitize == 0L,
          showModal(modalDialog("One or more custom features is not numeric."))
        )
      )
       removeUI(
      selector = "#core_features",
      multiple = TRUE,
      immediate = TRUE
    )
    removeUI(
      selector = "#custom_features",
      multiple = TRUE,
      immediate = TRUE
    )
    removeUI(
      selector = "#create_training",
      multiple = TRUE,
      immediate = TRUE
    )
    removeUI(
      selector = "#download_training",
      multiple = TRUE,
      immediate = TRUE
    )  

    removeUI(
      selector = "#build_model",
      multiple = TRUE,
      immediate = TRUE
    )  

    }
  })
  
  }

  if(message_custom_feature_warning()!=0L){
    showModal(modalDialog(message_custom_feature_warning()))
  }

}

})
  


  
  # Observe whether core features require normalization to a reference standard =================================
  observeEvent(input$core_features,{

    req(input$core_features)
    #showModal(modalDialog(paste("HELLO THERE",message$files_for_training_set_sanitize)))   

    #removeUI(
    #    selector = "#reference_standard_identifier",
     #   multiple = TRUE,
     #   immediate = TRUE
    #)


    #removeUI(
    #  selector = "#create_training",
    #  multiple = TRUE,
    #  immediate = TRUE
    #)
    #removeUI(
     # selector = "#download_training",
     # multiple = TRUE,
     # immediate = TRUE
    #)
    
    #Select the 2-letter LIPID MAPS. category of your files.

    removeUI(
      selector = "#create_training",
      multiple = TRUE,
      immediate = TRUE
    )
    removeUI(
      selector = "#download_training",
      multiple = TRUE,
      immediate = TRUE
    )  
    removeUI(
      selector = "#build_model",
      multiple = TRUE,
      immediate = TRUE
    )  

    removeUI(
      selector = "#upload_model",
      multiple = TRUE,
      immediate = TRUE
    )
    if (any(input$core_features %in% features$needs_normalization)) {

    
    removeUI(
      selector = "#download_model",
      multiple = TRUE,
      immediate = TRUE
    )
    
    ## Remove UI to upload model in tab 4 and display model upload message
    removeUI(
      selector = "#upload_model",
      multiple = TRUE,
      immediate = TRUE
    )
    
     removeUI(
        selector = "#reference_standard_identifier",
        multiple = TRUE,
        immediate = TRUE
      )

    removeUI(
      selector = "#create_training",
      multiple = TRUE,
      immediate = TRUE
    )
    removeUI(
      selector = "#download_training",
      multiple = TRUE,
      immediate = TRUE
    )

      training$all_standards <- get_reference_standards()

      ## Reference standard drop down UI
      insertUI(
        selector = "#tab_2_placeholder_4",
        where = "beforeEnd",
        ui = mainPanel(
          div(
            selectInput(
              "reference_standard_identifier",
              "Some of your features require normalization to a reference standard
              present in all of your samples. Select that standard here.",
              choices = training$all_standards,
              #selected = "",
              multiple = FALSE
            )
          ),
          id = "reference_standard_identifier"
        )
      )

      
      
    } else {
      removeUI(
        selector = "#reference_standard_identifier",
        multiple = TRUE,
        immediate = TRUE
      )
      
      ## No relativized features means no lipid identifier standard picked
      training$all_standards <- NULL

    }
    removeUI(
      selector = "#download_training",
      multiple = TRUE,
      immediate = TRUE
    )  
    ## UI action button to create training set
    insertUI(
      selector = "#tab_2_placeholder_5",
      where = "beforeEnd",
      ui = mainPanel(
        div(
          h3("Step 3"),
          actionButton(
            "create_training",
            "Click here to create your training set."
          ),
          id = "create_training"
        )
      )
    )
    #}
  })

  
  # Reactive to get core features with the correct names in each file =================================
  get_updated_core_features <- reactive({
    req(input$files_for_training_set)
    features$core_training <- update_core_features(
      input$core_features,
      tmpfiles_rs1$tmpfilename
    )
  })
  
  
  # Reactive to construct training set =================================
  get_training_set <- reactive({
  
    req(input$create_training)
    
    ## Replace withProgress with your method
    withProgress(message = "Generating the training set", value = 0.5, {
      training$output <- generate_training_set(
        tmpfiles_rs1$tmpfilename,
        features$core_training,
        input$custom_features,
        input$reference_standard_identifier,
        label$exceptions # check initialization for some default values
      )
    })
  })
  
  # Reactive to error check reference standard/component name =================================
  sanitize_reference_standard_component <- reactive({
    
    req(training$output, input$reference_standard_identifier)
    
    message$reference_component <- sanitize_reference_component(
      training$output[[2]], input$reference_standard_identifier
    )
    
  })
  
  # Reactive to get reference standard component name =================================
  get_reference_standard_component <- reactive({
    
    req(training$output, input$reference_standard_identifier)
    
    label$component_name <- get_reference_component(
      training$output[[2]], input$reference_standard_identifier
    )
  })
  # Reactive to remove Component.Name column from training set =================================
  remove_training_component_name <- reactive({
    req(training$output)
    
    training$output[[2]] <- remove_component_name(training$output[[2]])
  })
  
  # Reactive to get leave one out cv folds from training set =================================
  get_loocv_folds <- reactive({
    req(training$output)
    
    model$folds <- get_folds(training$output[[2]])
  })

    # Observe action button to generate training set =================================
  observeEvent(input$create_training, {
  #showModal(modalDialog(paste("HELLO THERE44")))
  #  removeUI(
  #    selector = "#build_model",
  #    multiple = TRUE,
  #    immediate = TRUE
  #  )

  #  removeUI(
  #    selector = "#download_training",
  #    multiple = TRUE,
  #    immediate = TRUE
  #  )
    
    ## Get core features (not the GUI names but the ones in the file)
    features$core_training <- get_updated_core_features()
    
    ## Create training set from input files
    ## Reactive returns a two-element list
    ## 1st element is the value of the subtracted retention time constant
    ## If that feature is not selected, 1st element = NULL
    ## 2nd element is the actual training set
    training$output <- get_training_set()
    
    
    ## Check whether the reference standard (lipid identifier) picked by the
    ## user corresponds to a single 'Component.Name'
    message$reference_component <- sanitize_reference_standard_component()

    if (message$reference_component == 1L) {

        validate(
          need(
            message$reference_component == 0L,
            showModal(modalDialog(paste(
              "The 'Lipid_identifier' of your selected reference standard is:",
              reference_standard, ".",
              "Please ensure that the corresponding row-values under the",
              "'Component.Name' of this",
              "standard is filled out in the 'Component.Name' column in your",
              "BATL-converted, SRM/MRM peak quantification files."))
            )
          )
        )
       removeUI(
      selector = "#core_features",
      multiple = TRUE,
      immediate = TRUE
    )
    removeUI(
      selector = "#custom_features",
      multiple = TRUE,
      immediate = TRUE
    )
    removeUI(
      selector = "#create_training",
      multiple = TRUE,
      immediate = TRUE
    )
    removeUI(
      selector = "#download_training",
      multiple = TRUE,
      immediate = TRUE
    )  

    removeUI(
      selector = "#build_model",
      multiple = TRUE,
      immediate = TRUE
    )  

    } else if (message$reference_component == 2L) {
        validate(
          need(
            message$reference_component == 0L,
            showModal(modalDialog(paste(
              "The 'Lipid_identifier' of your selected reference standard is:",
              reference_standard, ".",
              "Please ensure this standard corresponds to a single",
              "'Component.Name'",
              "in your BATL-converted, SRM/MRM peak quantification files.",
              "Currently,", reference_standard, "is labelled as",
              paste(unique(component_names), collapse = ", "),
              "under the 'Component.Name' column."))
            )
          )
        )
         removeUI(
      selector = "#core_features",
      multiple = TRUE,
      immediate = TRUE
    )
    removeUI(
      selector = "#custom_features",
      multiple = TRUE,
      immediate = TRUE
    )
    removeUI(
      selector = "#create_training",
      multiple = TRUE,
      immediate = TRUE
    )
    removeUI(
      selector = "#download_training",
      multiple = TRUE,
      immediate = TRUE
    )  

    removeUI(
      selector = "#build_model",
      multiple = TRUE,
      immediate = TRUE
    )  

    } else if (message$reference_component == 0L) {
      
      ## Get component name of the selected reference standard
      label$component_name <- get_reference_standard_component()
      
      
      #if ("Subtracted.RT" %in% ) {
      training$output[[2]] <- remove_training_component_name()
      #} else {
        
      #}
      
      model$folds <- get_loocv_folds()
      
      insertUI(
        selector = "#tab_2_placeholder_6",
        where = "beforeEnd",
        ui = mainPanel(
          div(
            br(),
            h3("Step 4"),
            p(
              paste(
                "You have successfully created your training set.",
                "Please head to the next tab to create the BATL model from your",
                "training set. Note that each lipid identifier must be observed",
                "at least 3 times in the training set to be included in the",
                "model.",
                "You may download the training set for your personal use below."
              )
            ),
            downloadButton(
              "download_training",
              "Click here to download your training set."
            )
          ),
          id = "download_training"
        )
      )
    }
  })

   # Server-side handling of the training set download button =================================
  output$download_training <- downloadHandler(
    filename = function() {
    #datefn <- as.POSIXct(Sys.time(), format = "%m/%d/%Y %H:%M:%S")
    #tsfn <- format(date1, format = "%m%d%Y%H%M%S")
      paste0("BATL_training_set_",Sys.time(), ".txt")
    }, 
    content = function(connection) {
      fwrite(training$output[[2]], connection, sep = "\t")
    }
  )
  tmpfiles_rs2 <- reactiveValues(tmpfilename = NULL)

 # Observe generated training set and reveal model builder =================================
  observeEvent(input$create_training, {
    tmpfiles_rs2$tmpfilename <-  tmpfiles_rs1$tmpfilename
  
     removeUI(
        selector = "#build_model",
        multiple = TRUE,
        immediate = TRUE
      )
      removeUI(
        selector = "#download_model",
        multiple = TRUE,
        immediate = TRUE
      )
    removeUI(
      selector = "#upload_model",
      multiple = TRUE,
      immediate = TRUE
    )
    
    if (message$reference_component == 0L) {

   removeUI(
        selector = "#build_model",
        multiple = TRUE,
        immediate = TRUE
      )
      removeUI(
        selector = "#download_model",
        multiple = TRUE,
        immediate = TRUE
      )
    removeUI(
      selector = "#upload_model",
      multiple = TRUE,
      immediate = TRUE
    )

      
      insertUI(
        selector = "#tab_3_placeholder_1",
        where = "beforeEnd",
        ui = mainPanel(
          div(
            h3("Step 1"),
            actionButton("build_model", "Click here to build your model.")
          ),
          id = "build_model"
        )
      )
    } else {
      removeUI(
        selector = "#build_model",
        multiple = TRUE,
        immediate = TRUE
      )
      removeUI(
        selector = "#download_model",
        multiple = TRUE,
        immediate = TRUE
      )
    }
  })

# TAB 3 - CONSTRUCTING THE BATL STATISTICAL MODEL -----------------------
  # Reactive to compute BATL model =================================
  
  compute_model <- reactive({
    model$output <- nb_build_model(
      library = training$output[[2]],
      folds = model$folds,
      features = c(features$core_training, input$custom_features),
      exhaustive = model$exhaustive,
      decision = model$decision,
      tolerance = model$tolerance,
      parallel_cores = model$parallel_cores,
      full_output = model$full_output,
      subtract_constant = training$output[[1]],
      component_name = label$component_name,
      vendor_format = input$input_file_conversion_confirm_vendor)[[1]][[1]]
  })
  
  
  # Observe model builder and build model + reveal model downloader =================================
  observeEvent(input$build_model, {

    removeUI(
      selector = "#download_model",
      multiple = TRUE,
      immediate = TRUE
    )
    
    ## Remove UI to upload model in tab 4 and display model upload message

    insertUI(
      selector = "#tab_4_placeholder_1",
      where = "beforeEnd",
      ui = mainPanel(
        div(
          p("Your model generated in tab 3 is already uploaded.")
        )
      )
    )
    
  withProgress(message = "Building BATL model...", value = 0.5, {
    model$output <- compute_model()
      })
    insertUI(
      selector = "#tab_3_placeholder_2",
      where = "beforeEnd",
      ui = mainPanel(
        div(
          br(),
          h3("Step 2"),
          p(
            paste(
              "You have successfully generated your BATL model.",
              "Please download your model and proceed to Tab 4 to",
              "to annotate SRM/MRM quantification files with it."
            )
          ),
          hr(),
          downloadButton(
            "download_model",
            "Click here to download your model."
          )
        ),
        id = "download_model"
      )
    )
  })
  
  ## Server-side handling of the model file download button
  output$download_model <- downloadHandler(
    filename = function() {
      paste0("BATL_model_", Sys.time(), ".txt")
    }, 
    content = function(connection) {
      nb_export_model(model$output, connection)
    }
  )
  
  



  # TAB 4 - ANNOTATING NEW PEAKS WITH THE MODEL -----------------------
  # Reactive to error-check model format =================================
  sanitize_model <- reactive({
    req(input$upload_model)
    message$upload_model <- sanitize_input_model(input$upload_model$datapath)
  })
  
  # Observe model upload if users start on tab 4 =================================
  observe({
    req(input$upload_model)
    
    ## Output: Error > 0L. No error == 0L.
    message$upload_model <- sanitize_model()
    
    ## Error-check for .txt extension only
    if (message$upload_model == 1L) {
        validate(
          need(
            message$upload_model == 0L,
            showModal(modalDialog(paste(
              "Uploaded model file must end with a .txt extension."))
            )
          )
        )
  
      removeUI(
        selector = "#label_peaks",
        multiple = TRUE,
        immediate = TRUE
      )
      removeUI(
        selector = "#annotate_file_downloader",
        multiple = TRUE,
        immediate = TRUE
      )
     }
    ## Error-check if model was successfully loaded
    else if (message$upload_model == 2L) {
        validate(
          need(
            message$upload_model == 0L,
            showModal(modalDialog(paste(
              "The file you uploaded is not recognized as a valid",
              "BATL model file."))
            )
          )
        )
 
      removeUI(
        selector = "#label_peaks",
        multiple = TRUE,
        immediate = TRUE
      )
      removeUI(
        selector = "#annotate_file_downloader",
        multiple = TRUE,
        immediate = TRUE
      )
    } else {
      model$output <- nb_import_model(input$upload_model$datapath)
    }
  })
  
  # Reactive to error-check peak upload format =================================
  sanitize_annotate_file <- reactive({
    req(input$upload_annotate_file)
    message$annotate_file_sanitize <- sanitize_vendor_format(
      input$upload_annotate_file$datapath
    )
  })
  
  # Reactive to predict vendor format =================================
  predict_annotate_file <- reactive({
    req(input$upload_annotate_file)
    training$vendor <- predict_vendor_format(
      input$upload_annotate_file$datapath
    )
  })
  
  # Reactive to load and convert format =================================
  convert_annotate_file <- reactive({
    label$output <- convert_to_batl_format(
      input$upload_annotate_file$datapath,
      "MultiQuant (SCIEX)",
      FALSE
    )
  })
  
  # Reactive to check the Lipid_identifier_MWBM column does not exist =================================
  check_unlabelled_annotate_file <- reactive({
    message$check_unlabelled <- check_unlabelled_file(label$output)
  })
  
  # Reactive to check the model component name is found in all samples =================================
  check_annotate_file_component_name <- reactive({
    message$check_component <- sanitize_component_name_samples(
      label$output,
      extract_model_meta_info(model$output, "component_name")
    )
  })
  
  # Reactive to annotate SRM/MRM quantification files =================================
  batl_annotate_peaks <- reactive({
    
    ## Modify this with your own progress bar
    withProgress(message = "Assigning annotations to your samples", value = 0.5, {
      label$output <- nb_label_peaks(
        filenames = label$output, #"/media/sf_Vault/Shiny_Stuff/batl_gui_all_tabs/test_files/MultiQuant_unlabelled_1.txt",
        model_filename = model$output,
        qstandard = extract_model_meta_info(
          model$output, "component_name"), #"C16-D31 Ceramide",
        qstandard_col = "Component.Name", # hardcoded (all vendor formats have this column)
        subtract_constant = as.numeric(extract_model_meta_info(
          model$output, "subtract_constant")),
        exceptions = label$exceptions)
      
      ## Deartifact peaks function
      label$output <- deartifact_peaks(
        filenames = label$output,
        category = input$upload_category, # tab 4 radio buttons
        Q1_tolerance = 0L, # hardcoded 0
        retention_tolerance = 2) # hardcoded 2
    })
  })
  
  
  # Observe unlabelled peak file upload =================================
  observeEvent(input$upload_annotate_file, {
    
    ## Output: Error > 0L. No error == 0L.
    message$annotate_file_sanitize <- sanitize_annotate_file()
    
    ## File upload error: wrong file extension
    if (message$annotate_file_sanitize == 1L) {
         validate(
          need(
            message$annotate_file_sanitize == 0L,
            showModal(modalDialog(paste(
              "Uploaded file or files in .zip must end with",
              ".txt, .csv, .tsv, or .xlsx extension." ))
            )
          )
        )
 
      removeUI(
        selector = "#label_peaks",
        multiple = TRUE,
        immediate = TRUE
      )
      removeUI(
        selector = "#annotate_file_downloader",
        multiple = TRUE,
        immediate = TRUE
      )
    }
    ## File upload error: zip file contains data from different vendors
    else if (message$annotate_file_sanitize == 2L) {
        validate(
          need(
            message$annotate_file_sanitize == 0L,
            showModal(modalDialog(paste(
              "Uploaded files in .zip must come from the same",
              "vendor software program."))
            )
          )
        )
 
      removeUI(
        selector = "#label_peaks",
        multiple = TRUE,
        immediate = TRUE
      )
      removeUI(
        selector = "#annotate_file_downloader",
        multiple = TRUE,
        immediate = TRUE
      ) 

    }
    ## (Partly) sanitized input file
    else {
      ## Predict the file format vendor and delete following UI if applicable
      label$vendor <- predict_annotate_file()

      removeUI(
        selector = "#label_peaks",
        multiple = TRUE,
        immediate = TRUE
      )
      removeUI(
        selector = "#annotate_file_downloader",
        multiple = TRUE,
        immediate = TRUE
      )
      affirm$annotate_peak_message <- 0L

      ## File upload error: file format not recognized or incorrect
      if (length(label$vendor) == 0) {
          validate(
            need(
              length(label$vendor) != 0L,
              showModal(modalDialog(paste(
                "Uploaded file is not a valid SRM/MRM peak quantification file",
                "and/or the format is not supported."))
              )
            )
          )

      removeUI(
        selector = "#label_peaks",
        multiple = TRUE,
        immediate = TRUE
      )
      removeUI(
        selector = "#annotate_file_downloader",
        multiple = TRUE,
        immediate = TRUE
      )
      }
      ## Completely sanitized file leads to radio buttons to confirm vendor format
      else {
        affirm$annotate_peak_message <- affirm$annotate_peak_message + 1L
        
        insertUI(
          selector = "#tab_4_placeholder_3",
          where = "beforeEnd",
          ui = mainPanel(
            div(
              h3("Step 4"),
              actionButton(
                "label_peaks",
                "Click here to label your quantification files."
              ),
              id = "label_peaks"
            )
          )
        )
      }
    }
  })
  
  
  # Reactive to confirm necessary columns for successful peak annotation =================================
  sanitize_annotate_file_columns <- reactive({
    req(input$upload_annotate_file, "MultiQuant (SCIEX)")
    
    message$columns_sanitize <- sanitize_input_columns(
      input$upload_annotate_file$datapath,
      "MultiQuant (SCIEX)"
    )
  })
  
  
  # Observe input file upload (and model file) and convert/annotate file(s) ------------------------------------------------
  observeEvent(input$label_peaks, {
    
    ## Convert the uploaded, unlabelled quantification files
    label$output <- convert_annotate_file()
    
    ## Return error if the file has already been annotated with Lipid_Identifier_MWBM column
    message$check_unlabelled <- check_unlabelled_annotate_file()
    
    if (message$check_unlabelled == 1L) {
        validate(
          need(
            message$check_unlabelled == 0L,
            showModal(modalDialog(paste(
              "One of your uploaded quantification files is already labelled.",
              "Ensure that all of your quantification files that you would like",
              "to label do not contain a'Lipid_identifier_MWBM' column."))
            )
          )
        )

      removeUI(
        selector = "#label_peaks",
        multiple = TRUE,
        immediate = TRUE
      )
      removeUI(
        selector = "#annotate_file_downloader",
        multiple = TRUE,
        immediate = TRUE
      )
    } else if (message$check_unlabelled == 0L) {
      
      ## Check for the necessary columns in the files to annotate
      message$columns_sanitize <- sanitize_annotate_file_columns()
      
      ## File upload error: this error should never trigger for MultiQuant
      if (message$columns_sanitize == 1L) {
          validate(
            need(
              message$columns_sanitize == 0L,
              showModal(modalDialog(paste(
                "Invalid MultiQuant file. Must contain the following columns:",
                "Sample Index, Sample Name, Index, Mass Info, Component Name,",
                "and Retention Time."))
              )
            )
          )

      removeUI(
        selector = "#label_peaks",
        multiple = TRUE,
        immediate = TRUE
      )
      removeUI(
        selector = "#annotate_file_downloader",
        multiple = TRUE,
        immediate = TRUE
      )
      }
      ## File upload error: this error may occur for MassHunter files
      else if (message$columns_sanitize == 2L) {
          validate(
            need(
              message$columns_sanitize == 0L,
              showModal(modalDialog(paste(
                "Invalid MassHunter file. Must contain the following columns",
                "in the 2nd row header:",
                " Name, Transition, RT."))
              )  
            )
          )

      removeUI(
        selector = "#label_peaks",
        multiple = TRUE,
        immediate = TRUE
      )
      removeUI(
        selector = "#annotate_file_downloader",
        multiple = TRUE,
        immediate = TRUE
      )
      }
      ## File upload error: this error may occur for MassLynx files
      else if (message$columns_sanitize == 3L) {
          validate(
            need(
              message$columns_sanitize == 0L,
              showModal(modalDialog(paste(
                "Invalid MassLynx file. Must contain the following columns",
                "under each 'compound' table:",
                "<1st column empty>, #, Sample Text, Quan Trace."))
              )
              
            )
          )

      removeUI(
        selector = "#label_peaks",
        multiple = TRUE,
        immediate = TRUE
      )
      removeUI(
        selector = "#annotate_file_downloader",
        multiple = TRUE,
        immediate = TRUE
      )
      } else {
        
        ## Check the component name in the model is found in all samples
        message$check_component <- check_annotate_file_component_name()
        
        if (message$check_component == 1L) {
            validate(
              need(
                message$check_component == 0L,
                showModal(modalDialog(paste(
                  "Some peaks have no matching reference standard for feature",
                  "normalization. Please ensure that",
                  extract_model_meta_info(model$output, "component_name"),
                  "is detected",
                  "in each of your samples you would like to annotate."))
                )
              )
            )

      removeUI(
        selector = "#label_peaks",
        multiple = TRUE,
        immediate = TRUE
      )
      removeUI(
        selector = "#annotate_file_downloader",
        multiple = TRUE,
        immediate = TRUE
      )
        } else {
          ## Assign annotations to the quantification files based on the model
          label$output <- batl_annotate_peaks()
          
          ## Reveal downloader UI
          insertUI(
            selector = "#tab_4_placeholder_4",
            where = "beforeEnd",
            ui = mainPanel(
              div(
                br(),
                h3("Step 5"),
                downloadButton(
                  "annotate_file_downloader",
                  "Click here to download your annotated quantification files."
                )
              ),
              id = "annotate_file_downloader"
            )
          )
          
        }
        
        
      }
      
    }
  })
  
  
  
  # Server-side handling to download annotated peak files ------------------------------------------------
  output$annotate_file_downloader <- downloadHandler(
    filename = function() {
      gsub(".xlsx",".txt", paste0("BATL_annotated_", Sys.time(), "_", input$upload_annotate_file)
      )
    },
    content = function(connection) {
      # Unzip files if necessary and get all file names
      filenames <- unzip_files(input$upload_annotate_file$datapath)
      
      ## Get rid of starting './' in the filenames
      filenames <- gsub("./", "", filenames)
      filenames <- paste0("BATL_annotated_", Sys.time(), "_", filenames) 
      
      ##
      if (length(filenames) > 1) {
        tmpdir <- tempdir()
        setwd(tempdir())
        for (i in 1:length(filenames)) {
          nb_export_labelled_file(label$output[[i]], filenames[i])
        }
        zip(zipfile = connection, files = filenames)
      } else {
        nb_export_labelled_file(label$output[[1]], connection)
      }
    }
  )























































}





shinyApp(ui, server)
