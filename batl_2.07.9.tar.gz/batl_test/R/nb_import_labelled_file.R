#' nb_import_labelled_file
#'
#' @description Wrapper function to import a tab-delimited, labelled peak file.
#'
#' @usage
#' nb_import_labelled_file(labelled_file)
#'
#' @param labelled_file Name and path of labelled peak file (ending in *.txt).
#'
#' @examples
#' \dontrun{
#' See batl-Introduction vignette for details
#' }
#'
#' @export nb_import_labelled_file
#'

nb_import_labelled_file <- function(labelled_file) {
  labelled_file <- fread(
  file = labelled_file,
  header = TRUE,
  sep = "\t",
  na.strings = "N/A",
  stringsAsFactors = FALSE)
  
  cnames <- colnames(labelled_file)
  naindex <- grep("^V[[:digit:]]+",cnames)
  if(length(naindex)>0){
  cnames <- cnames[-naindex[1]:-naindex[length(naindex)]]
  labelled_file <- labelled_file[,-naindex[1]:-naindex[length(naindex)]]
  } 
  cnames <- gsub("Acq Method","Acq. Method",cnames)
  cnames <- gsub("Conc Units","Conc. Units",cnames)
  
  cnames <- gsub("\\s+",".",cnames)
  oricol <- grep("Original\\.Filename",cnames)
  cnames[oricol] <- "Filename"


  labelled_file <- labelled_file[!(duplicated(labelled_file)), ] 
  colnames(labelled_file) <- cnames

  return(labelled_file)
}