#' map_library_features_is
#'
#' @description Appends feature columns to the data table output produced from
#' \code{\link{build_library}}.
#'
#' @usage
#' map_library_features_is(
#'     library,
#'     qsession,
#'     features,
#'     standard)
#'
#' @param library Output object from \emph{build_library}
#' @param qsession Vector of Multiquant qsession file paths. Same input as
#' \emph{build_library}.
#' @param features \emph{n}x2 matrix consisting of feature names/indices of
#' qsession columns and a boolean TRUE/FALSE column to denote whether these
#' features are normalized to an internal standard.
#' @param standard A single internal standard to normalize lipid label features
#' to. See \emph{Details} for more information.
#'
#' @format \tabular{lll}{
#' library \tab \tab data table object outputted from \emph{BuildLibrary}. \cr
#' qsession \tab \tab Character vector. \cr
#' features \tab \tab \emph{n}x2 character matrix. \cr
#' standard \tab \tab Character string.
#' }
#'
#' @details{
#' The exact same internal standard must be present across all qsessions that
#' you wish to incorporate into your library. This standard is used to normalize
#' the following features: area, height, relative retention time, subtracted
#' retention time. We recommend that the chosen internal standard has similar
#' a similar structure to the profiled lipid species of interest (i.e. they
#' should ionize and fragment similarly). \cr
#'
#' "Subtracted RT" is an optional feature that can be specified under
#' \emph{features}. It is an alternative method of retention time normalization
#' where peak RTs are subtracted by the RT of the corresponding internal
#' standard. It is similar to "Relative RT" found in Multiquant where peak RTs
#' are divided by the corresponding internal standard.
#' }
#'
#' @return
#' A data table object containing all columns found from the output of
#' \emph{build_library} plus additional feature columns. These feature columns
#' are provided by the \emph{features} input parameter.
#'
#' @note
#' A possible error is likely to occur when mapping features to the
#' library. It is possible that an internal standard was not spiked into
#' your sample. Thus, the code will fail if features require internal
#' standard normalization and the standard cannot be found.
#'
#' @seealso \code{\link{build_library}}
#'
#' @examples{
#' \dontrun{
#' ## Parameters
#' my_library # generated from |BuildLibrary|
#' qsession <- c(
#'     "/path/.../Qsession_file_1.txt",
#'     "/path/.../Qsession_file_2.txt")
#' features <- matrix(c(
#'     "Retention Time", FALSE,
#'     "Area", TRUE,
#'     "Height", TRUE,
#'     "Width at 50%", FALSE,
#'     "Tailing Factor", FALSE,
#'     "Asymmetry Factor", FALSE,
#'     "Relative RT", TRUE,
#'     "Subtracted RT", TRUE),
#'     ncol = 2, byrow = TRUE)
#' standard <- "SPH000001"
#'
#' ## Append features to library
#' library <- batl:::map_library_features_is(
#'     library = my_library,
#'     qsession = qsession,
#'     features = features,
#'     standard = standard
#' }
#' }
#'
# #' @export map_library_features_is
#' @keywords internal

map_library_features_is <- function(library, qsession, features, standard) {

    ## Null strategy to pass R CMD check
    `Retention Time` <- Sample.Name <- Qsession <- Index <- Qsession <- NULL
    Q3 <- `.` <- Feature <- Standard_normalize <- Q1 <- Lipid_identifier <- NULL
    Detected <- Sample.Index <- Filename <- NULL

    if (length(standard) != 1) {
        stop("A single internal standard must be specified for 'standard'")
    }

    ## Convert qsession feature names to column indices if necessary;
    if (suppressWarnings(
        all(is.na(as.numeric(features[, 1]))))) {
        temp_qsession <- fread(
            qsession[1],
            sep = "\t",
            header = TRUE, nrows = 0)

        ## Special case for relative and subtracted RT
        features_copy <- features
        features[, 1][
            which(features[, 1] %in% "Relative RT")] <- "Retention Time"
        features[, 1][
            which(features[, 1] %in% "Subtracted RT")] <- "Retention Time"

        features[, 1] <- match(features[, 1], colnames(temp_qsession))
        features[, 2] <- as.numeric(as.logical(features[, 2]))
        class(features) <- "numeric"

        if (any(is.na(features[, 1]))) {
            stop(paste0(
                "Feature name(s) ",
                features[, 1][which(is.na(features[, 1]))],
                " do not exist in the qsession files."))
        }
    } else if (suppressWarnings(
        is.null(any(is.na(as.numeric(features[, 1])))))) {
        ## Error if user mixes feature names and indices
        stop("Do not mix feature names with feature column indices.")
    }

    ## Make sure relative RT and subtracted RT are normalized to standard
    if (any(features_copy[, 1] %in% "Relative RT")) {
        if (length(features_copy[
            which(features_copy[, 1] %in% "Relative RT"), 2]) == 1) {
            if (features_copy[
                which(features_copy[, 1] %in% "Relative RT"), 2] == FALSE) {
                stop(paste0(
                    "Relative RT must be normalized. ",
                    "Set second column to TRUE."))
            }
        }
    }
    if (any(features_copy[, 1] %in% "Subtracted RT")) {
        if (length(features_copy[
            which(features_copy[, 1] %in% "Subtracted RT"), 2]) == 1) {
            if (features_copy[
                which(features_copy[, 1] %in% "Subtracted RT"), 2] == FALSE) {
                stop(paste0(
                    "Subtracted RT must be normalized. ",
                    "Set second column to TRUE."))
            }
        }
    }

    ## Get sample names of all qsessions matched to the library
    qsession_run_names <- vector("list", length = length(qsession))
    for (kFile in seq_along(qsession)) {
        qsession_run_names[[kFile]] <- gsub(
            "\\s+", ".", as.vector(unlist(unique(fread(
                qsession[kFile],
                select = c(4),
                sep = "\t",
                header = TRUE)))))
    }
    names(qsession_run_names) <- qsession

    ## Unlist sample names, figure out which ones are duplicates, mark with NA
    qsession_unlist <- as.character(unlist(qsession_run_names))
    qsession_unlist[which(duplicated(qsession_unlist))] <- NA

    ## Convert vector back to list with original lengths and remove NA
    col_2 <- cumsum(as.numeric(lengths(qsession_run_names)))
    col_1 <- c(1, (col_2 + 1)[seq_len(length(col_2) - 1)])
    cmat <- as.matrix(cbind(col_1, col_2))
    for (kList in seq_len(length(qsession_run_names))) {
        qsession_run_names[[kList]] <- qsession_unlist[
            seq(cmat[kList, 1], cmat[kList, 2], by = 1)]
    }
    qsession_run_names <- lapply(qsession_run_names, function(x) x[!(is.na(x))])

    ## Only keep qsession names shared in training data
    for (kFile in seq_along(qsession_run_names)) {
        for (kRun in seq_along(qsession_run_names[[kFile]])) {
            if (length(which(
                library[, unique(Sample.Name)] %in%
                qsession_run_names[[kFile]][kRun])) == 0) {
                qsession_run_names[[kFile]][kRun] <- NA
            } else if (length(which(
                library[, unique(Sample.Name)] %in%
                qsession_run_names[[kFile]][kRun])) > 1) {
                stop(paste0(
                    "Sample ",
                    qsession_run_names[[kFile]][kRun],
                    " matched multiple column names in the training",
                    " dataset. Ensure that all duplicated names are",
                    " removed."))
            }
        }
    }
    qsession_run_names <- lapply(qsession_run_names, function(x) x[!(is.na(x))])
    qsession_run_names <- qsession_run_names[lengths(qsession_run_names) > 0]

    ## Special case if retention time (56) is selected and normalized == T
    ## (Relative RT = RT / RT_internal_standard)
    ## (Subtracted RT = RT - RT_internal_standard)
    relative_rt_condition <- FALSE
    subtract_rt_condition <- FALSE
    index_1 <- features[, 1] == 56
    index_2 <- features[, 2] == TRUE
    index_3 <- index_1 + index_2
    if (any(index_3 == 2)) {
        if ("Relative RT" %in% features_copy) {
            relative_rt_condition <- TRUE
        }
        if ("Subtracted RT" %in% features_copy) {
            subtract_rt_condition <- TRUE
        }
    }

    ## Load qsession file and store feature data to a new data table
    for (kFile in seq_along(qsession_run_names)) {

        ## Add column for relative retention time if applicable
        qsession_file <- fread(
            names(qsession_run_names)[kFile],
            sep = "\t",
            header = TRUE,
            na.strings = "N/A",
            select = unique(c(2, 4, 1, as.numeric(features[, 1]))))

        ## If relative RT and RT are present, we need to load the RT and then
        ## copy that column and relabel it as relative RT
        if (
            relative_rt_condition == TRUE &
            subtract_rt_condition == FALSE &
            !("Retention Time" %in% features_copy[, 1])) {
            setnames(qsession_file, "Retention Time", "Relative.RT")
        } else if (
            relative_rt_condition == FALSE &
            subtract_rt_condition == TRUE &
            !("Retention Time" %in% features_copy[, 1])) {
            setnames(qsession_file, "Retention Time", "Subtracted.RT")
        } else if (
            relative_rt_condition == TRUE &
            subtract_rt_condition == FALSE &
            "Retention Time" %in% features_copy[, 1]) {
            qsession_temp <- fread(
                names(qsession_run_names)[kFile],
                sep = "\t",
                header = TRUE,
                na.strings = "N/A",
                select = 56)
            qsession_file[, "Relative.RT" := qsession_temp[, `Retention Time`]]
        } else if (
            relative_rt_condition == FALSE &
            subtract_rt_condition == TRUE &
            "Retention Time" %in% features_copy[, 1]) {
            qsession_temp <- fread(names(
                qsession_run_names)[kFile],
                sep = "\t",
                header = TRUE,
                na.strings = "N/A",
                select = 56)
            qsession_file[
                , "Subtracted.RT" := qsession_temp[, `Retention Time`]]
        } else if (
            relative_rt_condition == TRUE &
            subtract_rt_condition == TRUE &
            !("Retention Time" %in% features_copy[, 1])) {
            qsession_temp <- fread(
                names(qsession_run_names)[kFile],
                sep = "\t",
                header = TRUE,
                na.strings = "N/A",
                select = 56)
            qsession_file[, "Relative.RT" := qsession_temp[, `Retention Time`]]
            qsession_file[
                , "Subtracted.RT" := qsession_temp[, `Retention Time`]]
            qsession_file[, "Retention Time" := NULL]
        } else if (
            relative_rt_condition == TRUE &
            subtract_rt_condition == TRUE &
            "Retention Time" %in% features_copy[, 1]) {
            qsession_temp <- fread(
                names(qsession_run_names)[kFile],
                sep = "\t",
                header = TRUE,
                na.strings = "N/A",
                select = 56)
            qsession_file[, "Relative.RT" := qsession_temp[, `Retention Time`]]
            qsession_file[
                , "Subtracted.RT" := qsession_temp[, `Retention Time`]]
        }

        ## Remove spaces in names
        colnames(qsession_file) <- gsub("\\s+", ".", colnames(qsession_file))
        qsession_file[, Sample.Name := gsub("\\s+", ".", Sample.Name)]

        ## Remove any runs in the Qsession file not present in the run name list
        qsession_file <- qsession_file[
            Sample.Name %in% qsession_run_names[[kFile]]]

        ## Column names to transfer from qsession file to library
        keep_col <- colnames(qsession_file)[
            (grep("^Index$", colnames(qsession_file)) + 1):ncol(qsession_file)]

        ## Add qsession file name
        qsession_file[, "Filename" := names(qsession_run_names)[kFile]]
        qsession_file[, Filename := gsub("\\s+", ".", Filename)]

        ## Create output file of features with Qsession, Sample.Name, and Index
        ## for merging
        if (kFile == 1) {
            qsession_bind <- qsession_file
        } else {
            qsession_bind <- rbind(qsession_bind, qsession_file)
        }
    }

    ## Combine/merge library with feature values
    setkey(library, Filename, Sample.Index, Sample.Name, Index)
    setkey(qsession_bind, Filename, Sample.Index, Sample.Name, Index)
    library <- merge(library, qsession_bind, all = TRUE)

    ## Feature names in qsession
    feature_names <- gsub("\\s+", ".", features_copy[, 1])

    ## Normalize features if specified
    for (kFeature in seq_len(nrow(features))) {
        if (as.logical(features[kFeature, 2] == TRUE)) {
            library[, "Standard_normalize" := NA_real_]

            fname <- feature_names[kFeature]
            setnames(library, fname, "Feature")

            library[
                Lipid_identifier == standard
                , Standard_normalize := Feature]
            q3 <- library[
                !(is.na(Standard_normalize)) &
                    Lipid_identifier == standard
                , unique(Q3)]

            if (length(q3) != 0) {
                test_a <- library[
                    Q3 == q3 & !(is.na(Standard_normalize)),
                    Standard_normalize
                    , by = c("Sample.Index", "Sample.Name")]
                test_b <- unique(library[
                    Q3 == q3
                    , c("Sample.Index", "Sample.Name")])
                if (nrow(test_a) > nrow(test_b)) {
                    dup <- names(which(table(test_a[, Sample.Name]) > 1))
                    dup <- paste("\n", dup, collapse = "\n")
                    stop(paste0(
                        "The library contains duplicated sample ",
                        "names within a Qsession file:", dup))
                } else if (nrow(test_a) < nrow(test_b)) {
                    check <- test_b[
                        !(test_b$Sample.Name %in% test_a$Sample.Name)
                        , Sample.Name]
                    check <- paste(check, collapse = "\n")
                    stop(paste0(
                        "The library does not contain the ",
                        "standard ",
                        standard,
                        " in the following sample runs:\n",
                        check))
                } else {
                    library[
                        , Standard_normalize := Standard_normalize[
                            which(!(is.na(Standard_normalize)))],
                        by = c("Sample.Index", "Sample.Name")]
                }
            }

            if (fname == "Subtracted.RT") {
                library[, Feature := Feature - Standard_normalize]
            } else {
                library[, Feature := Feature / Standard_normalize]
            }
            setnames(library, "Feature", fname)
            library[, c("Standard_normalize") := NULL]
        }
    }

    ## Remove peaks with NA Q1 and Q3 (these ones do not match to the library)
    library <- library[!(is.na(Q1))]

    library <- unique(
        library,
        by = c("Q1", "Q3", "Lipid_identifier", "Sample.Index", "Sample.Name"))

    return(library)
}
