#' spreadsheet_mismatches
#'
#' @description Finds all mismatches between a master Excel spreadsheet of
#' annotated lipid species and a vector of qsession files by matching the
#' retention time feature.
#'
#' @usage
#' spreadsheet_mismatches(
#'     training,
#'     qsession)
#'
#' @param training Path referencing a master Excel spreadsheet.
#' @param qsession Vector of Multiquant qsession file paths.
#'
#' @format \tabular{lll}{
#' training \tab \tab  Character string. \cr
#' qsession \tab \tab Character vector. \cr
#' }
#'
#' @return
#' A data table is returned with several columns. In general, non-NA .qsession
#' column names means a peak in the qsession file was not recorded in the
#' master Excel spreadsheet (garbage or low-confidence peaks, for example).
#' Non-NA .library column names mean a peak entered into the library could not
#' be matched to the qsession files. These mismatches should be addressed
#' because it means the Excel spreadsheet does not match the raw qsession files
#' (perhaps data entry mistakes in the spreadsheet or peaks were re-selected
#' in the qsession files, for example). The "Lipid_identifier.qsession" column
#' ## is always
#' set to NA.The last column indicates where a sample run was duplicated within
#' or across qsession files. For example, an analyst could output a qsession
#' file, reselect peaks, then output another qsession file. In this case, it is
#' important to insert the latest qsession files that are most likely to match
#' the master Excel spreadsheet.
#'
#' @examples
#' \dontrun{
#'
#' ## Parameters
#' training <- "/path/.../MasterSphingolipids.xlsx"
#' qsession <- c(
#'     "/path/.../Qsession_file_1.txt",
#'     "/path/.../Qsession_file_2.txt")
#'
#' ## Find mismatches
#' spreadsheet_mismatches(
#'     training = training,
#'     qsession = qsession)
#' }
#'
#' @importFrom data.table as.data.table
#'
# #' @export spreadsheet_mismatches
#' @keywords internal

spreadsheet_mismatches <- function(training, qsession) {

    ## Null strategy to pass R CMD check
    Sample.Name <- Duplicated_sample_name <- NULL
    Lipid_identifier.library <- NULL

    ## Get sample names of all qsessions
    qsession_run_names <- vector("list", length = length(qsession))
    for (kFile in seq_along(qsession)) {
        qsession_run_names[[kFile]] <- gsub(
            "\\s+",
            ".",
            as.vector(unlist(unique(fread(
                qsession[kFile],
                select = c(4),
                sep = "\t",
                header = TRUE)))))
    }
    names(qsession_run_names) <- qsession

    ## Unlist sample names, figure out which ones are duplicates
    qsession_unlist <- as.character(unlist(qsession_run_names))
    dups <- qsession_unlist[which(duplicated(qsession_unlist))]

    ## Sample runs may be duplicated but peaks may have been re-picked
    overlap <- vector(mode = "list", length = length(qsession))
    for (kQ in seq_along(qsession)) {

        ## Build library
        library <- build_library(
            training = training,
            qsession = qsession[kQ],
            training_info = NA,
            mismatch = TRUE)

        ## Only keep useful stuff for merging later
        library[[2]] <- library[[2]][
            , c("Q1",
                "Q3",
                "Lipid_identifier",
                "Run",
                "Retention.Time")]
        setcolorder(
            library[[2]],
            c(
                "Run",
                "Q1",
                "Q3",
                "Retention.Time",
                "Lipid_identifier"))
        setnames(library[[2]], "Run", "Sample.Name")
        library[[3]] <- library[[3]][
            , c("Filename",
                "Sample.Index",
                "Sample.Name",
                "Retention.Time",
                "Q1",
                "Q3",
                "Lipid_identifier")]
        setcolorder(
            library[[3]],
            c(
                "Filename",
                "Sample.Index",
                "Sample.Name",
                "Q1",
                "Q3",
                "Retention.Time",
                "Lipid_identifier"))

        ## Merge based on sample name and feature
        setkey(library[[2]], Sample.Name, "Retention.Time")
        setkey(library[[3]], Sample.Name, "Retention.Time")

        overlap[[kQ]] <- merge(library[[2]], library[[3]], all = TRUE)
        setnames(overlap[[kQ]], "Q1.x", "Q1.library")
        setnames(overlap[[kQ]], "Q3.x", "Q3.library")
        setnames(overlap[[kQ]], "Q1.y", "Q1.filename")
        setnames(overlap[[kQ]], "Q3.y", "Q3.filename")
        setnames(
            overlap[[kQ]], "Lipid_identifier.x", "Lipid_identifier.library")
        setnames(
            overlap[[kQ]], "Lipid_identifier.y", "Lipid_identifier.filename")
    }
    overlap <- do.call("rbind", overlap)
    overlap[, "Duplicated_sample_name" := FALSE]
    overlap[Sample.Name %in% dups, Duplicated_sample_name := TRUE]
    setkey(overlap, Sample.Name, Lipid_identifier.library)

    return(overlap)
}
