#' deartifact_export_peaks
#'
#' @description Wrapper function to export a peak file from
#' \code{\link{deartifact_peaks}}.
#'
#' @usage
#' deartifact_export_peaks(file, filename)
#'
#' @param file Data table of peak file with the Insource_annotation column.
#' @param filename Name and path of output text file (ending in *.txt)
#'
#' @examples
#' \dontrun{
#' See batl-Introduction vignette for details
#' }
#'
#' @export deartifact_export_peaks
#'

deartifact_export_peaks <- function(file, filename) {
    if (!(is.data.frame(file))) {
        stop("file must be a data.frame/data.table object.")
    }
    if (!(is.character(filename))) {
        stop("filename must be a string.")
    }
    if (grepl(".txt$", filename) == FALSE) {
        stop("filename must end with a '.txt' extension.")
    }

    file <- as.data.table(file)
    fwrite(
        x = file,
        file = filename,
        sep = "\t",
        row.names = FALSE,
        col.names = TRUE)
}
