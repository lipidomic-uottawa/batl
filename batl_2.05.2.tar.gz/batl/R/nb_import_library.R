#' nb_import_library
#'
#' @description Wrapper function to import a BATL library from a text file.
#'
#' @usage
#' nb_import_library(library)
#'
#' @param library Name and path of the targeted lipidomics library.
#'
#' @details
#' \tabular{lll}{
#' library \tab \tab String. \cr
#' }
#'
#' @examples
#' \dontrun{
#' See batl-Introduction vignette
#' }
#'
#' @export nb_import_library
#'

nb_import_library <- function(library) {

    library <- fread(
        file = library,
        header = TRUE,
        sep = "\t",
        stringsAsFactors = FALSE)

    ## Remove blank rows if these are somehow scanned in
    library <- library[!(apply(is.na(library) | library == "", 1, all)), ]

    return(library)
}
