#' nb_scatterplot
#'
#' @description Wrapper function to create result plots for all feature
#' combinations explored during \emph{k}-fold cross validation training data.
#' These plots include identification accuracies, unassignment rates, and
#' unassignment accuracies.
#'
#' @usage
#' nb_scatterplot(scores)
#'
#' @param scores Scores produced from \emph{training_results}.
#'
#' @return
#' Scatterplot of binary accuracies for each feature combination.
#'
#' @details
#' \tabular{lll}{
#' scores \tab \tab Data table object.
#' }
#'
#' @examples
#' \dontrun{
#' See batl-Introduction vignette
#' }
#'
#' @importFrom stats sd
# #' @import grDevices
#' @importFrom graphics arrows plot segments plot.new axis legend par text
#' @importFrom data.table setorder
#' @importFrom stats t.test
#'
#' @export nb_scatterplot

nb_scatterplot <- function(scores) {

    ## Null strategy to pass R CMD check
    kFold <- Decision <- `True Prediction` <- `False Prediction` <- NULL
    Identification_accuracy <- `No Prediction` <- Unassignment_rate <- NULL
    `No Prediction (True)` <- `No Prediction (False)` <- NULL
    Unassignment_accuracy <- `Feature Combination` <- NULL
    `Number of Features` <- Decision_col <- Mean_ia <- Se_ia <- NULL
    Keep <- Mean_ur <- Se_ur <- Mean_ua <- Se_ua <- NULL
    t.test <- segments <- par <- axis <- legend <- recordPlot <- NULL
    `.GRP` <- text <- NULL

    if (length(scores[, unique(`Feature Combination`)]) < 2) {
        stop(paste0(
            "scores should contain 2 unique feature combinations or more."))
    }
    ## Plot modifications to make things pretty
    dt <- copy(scores)
    dt[, kFold := as.factor(kFold)]
    dt[, Decision := as.factor(Decision)]

    ## Identification accuracy
    dt[
        , "Identification_accuracy" := `True Prediction` /
            (`True Prediction` + `False Prediction`)]
    dt[
        , "Mean_ia" := mean(Identification_accuracy)
        , by = c("Feature Combination", "Decision")]
    dt[
        , "Se_ia" := sd(Identification_accuracy) / sqrt(.N)
        , by = c("Feature Combination", "Decision")]

    ## Unassignment rate
    dt[
        , "Unassignment_rate" := `No Prediction` /
            (`No Prediction` + `True Prediction` + `False Prediction`)]
    dt[
        , "Mean_ur" := mean(Unassignment_rate)
        , by = c("Feature Combination", "Decision")]
    dt[
        , "Se_ur" := sd(Unassignment_rate) / sqrt(.N)
        , by = c("Feature Combination", "Decision")]

    ## Unassignment accuracy
    dt[
        , "Unassignment_accuracy" := `No Prediction (True)` /
            (`No Prediction`)]
    dt[
        , "Mean_ua" := mean(Unassignment_accuracy, na.rm = TRUE)
        , by = c("Feature Combination", "Decision")]
    dt[
        , "Se_ua" := sd(Unassignment_accuracy, na.rm = TRUE) / sqrt(.N),
        by = c("Feature Combination", "Decision")]

    dt[
        , `Feature Combination` := gsub("[a-z|.]", "", `Feature Combination`)]

    dt_original <- copy(dt)

    dt <- unique(dt, by = c(
        "Mean_ia",
        "Se_ia",
        "Decision",
        "Number of Features"))

    ## Order data table rows by descending identification accuracy, grouped by
    ## the number of features in model
    copy_dt_final <- vector(
        "list", length = length(dt[, unique(Decision)]))
    for (kDec in seq_along(dt[, unique(Decision)])) {
        copy_temp <- dt[Decision == unique(Decision)[kDec]]
        setorder(copy_temp, "Decision", `Number of Features`, "Mean_ia")
        copy_dt_final[[kDec]] <- copy_temp
    }
    copy_dt_final <- do.call("rbind", copy_dt_final)
    rm(copy_temp)

    ## More ordering to weave decision rules together
    decision_order <- as.character(copy_dt_final[, unique(Decision)])
    num_order <- nrow(copy_dt_final) / length(decision_order)
    copy_dt_final[
        , "Decision_col" := rep(
            seq(1, num_order), times = length(decision_order))]
    split_list <- vector("list", length = length(decision_order))
    for (kDec in seq_along(decision_order)) {
        split_list[[kDec]] <- copy_dt_final[Decision == decision_order[kDec]]
    }
    copy_dt_final <- rbindlist(split_list)[order(Decision_col)]

    ## Plot identification accuracy
    x_var <- rep(
        seq(
            1,
            (nrow(copy_dt_final) / length(copy_dt_final[, unique(Decision)]))),
        each = length(copy_dt_final[, unique(Decision)]))
    y_var <- copy_dt_final[, Mean_ia]
    y_var_ci <- copy_dt_final[, Se_ia]

    if (length(decision_order) == 1) {
        my_col <- "#F8766D"
    } else if (length(decision_order) == 2) {
        my_col <- c("#F8766D", "#7CAE00")
    } else if (length(decision_order) == 3) {
        my_col <- c("#F8766D", "#7CAE00", "#00BFc4")
    }

    par(mar = c(4,4,2,0), oma = c(0,0,0,0))
    plot(
        x_var,
        y_var,
        ylim = c(min(y_var - y_var_ci), 1.0),
        col = "black",
        pch = 21, bg = my_col,
        xaxt = 'n',
        xlab = "",
        ylab = "Identification rate (%)",
        frame.plot = TRUE)
    arrows(
        x0 = x_var,
        y0 = y_var - y_var_ci,
        x1 = x_var,
        y1 = y_var + y_var_ci,
        code = 3,
        angle = 90,
        length = 0.05)
    par(new=TRUE)
    plot(
        x_var,
        y_var,
        ylim = c(min(y_var - y_var_ci), 1.0),
        col = "black",
        pch = 21, bg = my_col,
        xaxt = 'n', xlab = "", ylab = "")
    axis(
        1,
        at = seq(
            1, (nrow(copy_dt_final) /
                    length(copy_dt_final[, unique(Decision)]))),
        labels = copy_dt_final[, unique(`Feature Combination`)],
        cex.axis = 0.2,
        las = 2)

    ## Compound legend
    legend(
        "bottomright",
        pch = 21,
        legend = decision_order,
        col = my_col,
        pt.bg = my_col,
        bty = "n",
        pt.cex = 1,
        cex = 1.0,
        text.col = "black",
        horiz = FALSE,
        inset = c(0.01, 0.01))

    legend(
        "bottomright",
        pch = 21,
        legend = decision_order,
        col = "black",
        bty = "n",
        pt.cex = 1,
        cex = 1.0,
        text.col = "black",
        horiz = FALSE,
        inset = c(0.01, 0.01))
    p1 <- recordPlot()

    ## Plot identification accuracies for the best combination of N features
    copy_dt_final[
        , "Keep" := ifelse(Mean_ia == max(Mean_ia), TRUE, FALSE)
        , by = "Number of Features"]
    copy_dt_final <- copy_dt_final[Keep == TRUE]
    copy_dt_final[, "Keep" := NULL]
    copy_dt_final[, "Subset" := .GRP, by = c("Feature Combination", "Decision")]
    copy_dt_final <- copy_dt_final[
        match(unique(copy_dt_final$Subset), copy_dt_final$Subset), ]

    best_fcombs <- copy_dt_final[, unique(`Feature Combination`)]
    dt_original <- dt_original[`Feature Combination` %in% best_fcombs]
    if ("MWBM" %in% decision_order) {
        test_decision <- "MWBM"
    } else if ("MAP" %in% decision_order) {
        test_decision <- "MAP_dup"
    } else {
        test_decision <- "MAP_nodup"
    }

    ## Significance testing
    sig_asterisk <- rep(
        "",
        length(dt_original[, unique(`Feature Combination`)]) - 1)
    for (i in seq_along(sig_asterisk)) {
        ttest <- t.test(
            dt_original[
                Decision == test_decision &
                    `Feature Combination` == unique(`Feature Combination`)[i]
                , Identification_accuracy],
            dt_original[
                Decision == test_decision &
                    `Feature Combination` == unique(`Feature Combination`)[i+1]
                , Identification_accuracy],
            alternative = "two.sided",
            paired = FALSE,
            var.equal = FALSE,
            conf.level = 0.95)
        if (ttest$p.value < 0.05) {
            sig_asterisk[i] <- "*"
        }
    }

    ## Asterisk vector: either all asterisks, all n.s., starts with n.s. or
    ## starts with asterisk
    ## Find the index of the first n.s.
    stop_var <- 0
    idx <- 0
    for (i in seq_along(sig_asterisk)) {
        if (stop_var == 0 & sig_asterisk[i] == "") {
            stop_var <- 1
            idx <- i
        }
    }

    ##
    if (idx == 1) {
        sig_asterisk <- character()
    } else if (idx > 1) {
        sig_asterisk <- sig_asterisk[seq_len((idx-1))]
    }
    idx <- length(sig_asterisk)

    ## Coordinates for significance bars
    x_var_sig <- seq(1, idx)
    y_var_sig <- copy_dt_final[
        Decision == test_decision & `Number of Features` %in% seq_len(idx)
        , Mean_ia]

    ## Identification accuracy of best subset of feature combinations
    x_var <- rep(
        seq(
            1,
            (nrow(copy_dt_final) / length(copy_dt_final[, unique(Decision)]))),
        each = length(copy_dt_final[, unique(Decision)]))
    y_var <- copy_dt_final[, Mean_ia]
    y_var_ci <- copy_dt_final[, Se_ia]

    par(mar = c(8,4,2,0), oma = c(0,0,0,0))
    plot(
        x_var,
        y_var,
        ylim = c(min(y_var - y_var_ci) - 0.2, 1.2),
        col = "black",
        pch = 21, bg = my_col,
        xaxt = 'n',
        xlab = "",
        ylab = "Identification rate (%)",
        frame.plot = TRUE)

    y_down <- y_var - y_var_ci
    y_down[y_down == 0] <- -10e-5
    y_up <- y_var + y_var_ci
    y_up[y_up == 0] <- 10e-5

    arrows(
        x0 = x_var,
        y0 = y_down,
        x1 = x_var,
        y1 = y_up,
        code = 3,
        angle = 90,
        length = 0.05)
    par(new=TRUE)
    plot(
        x_var,
        y_var,
        ylim = c(min(y_var - y_var_ci) - 0.2, 1.2),
        col = "black",
        pch = 21, bg = my_col,
        xaxt = 'n', xlab = "", ylab = "")
    axis(
        1,
        at = seq(
            1, (nrow(copy_dt_final) /
                    length(copy_dt_final[, unique(Decision)]))),
        labels = copy_dt_final[, unique(`Feature Combination`)],
        cex.axis = 0.5,
        las = 2)

    for (i in seq_along(sig_asterisk)){
        ## Horizontal bar
        segments(
            x0 = x_var_sig[i] + 0.05,
            y0 = 1.2 * 0.90,
            x1 = x_var_sig[i] + 1 - 0.05,
            y1 = 1.2 * 0.90)

        ## Vertical bars
        segments(
            x0 = x_var_sig[i] + 0.05,
            y0 = 1.2 * 0.90,
            x1 = x_var_sig[i] + 0.05,
            y1 = 1.2 * 0.90)
        segments(
            x0 = x_var_sig[i] + 1 - 0.05,
            y0 = 1.2 * 0.90,
            x1 = x_var_sig[i] + 1 - 0.05,
            y1 = 1.2 * 0.90)

        ## Significance asterisk
        text(
            x = (x_var_sig[i] + x_var_sig[i] + 1) / 2,
            y = 1.2 * 0.93,
            labels = sig_asterisk[i])
    }
    p2 <- recordPlot()

    ## Significance testing for unassignment rates
    sig_asterisk <- rep(
        "", length(dt_original[, unique(`Feature Combination`)]) - 1)
    for (i in seq_along(sig_asterisk)) {
        ttest <- t.test(
            dt_original[
                Decision == test_decision &
                    `Feature Combination` == unique(`Feature Combination`)[i]
                , Unassignment_rate],
            dt_original[
                Decision == test_decision &
                    `Feature Combination` == unique(`Feature Combination`)[i+1]
                , Unassignment_rate],
            alternative = "two.sided",
            paired = FALSE,
            var.equal = FALSE,
            conf.level = 0.95)
        if (ttest$p.value < 0.05) {
            sig_asterisk[i] <- "*"
        }
    }

    ## Asterisk vector: either all asterisks, all n.s., starts with n.s. or
    ## starts with asterisk
    ## Find the index of the first n.s.
    stop_var <- 0
    idx <- 0
    for (i in seq_along(sig_asterisk)) {
        if (stop_var == 0 & sig_asterisk[i] == "") {
            stop_var <- 1
            idx <- i
        }
    }

    ##
    if (idx == 1) {
        sig_asterisk <- character()
    } else if (idx > 1) {
        sig_asterisk <- sig_asterisk[seq_len((idx-1))]
    }
    idx <- length(sig_asterisk)

    ## Coordinates for significance bars
    x_var_sig <- seq(1, idx)
    y_var_sig <- copy_dt_final[
        Decision == test_decision & `Number of Features` %in% seq_len(idx)
        , Mean_ur]

    ## Unassignment rates plot
    x_var <- rep(
        seq(
            1,
            (nrow(copy_dt_final) / length(copy_dt_final[, unique(Decision)]))),
        each = length(copy_dt_final[, unique(Decision)]))
    y_var <- copy_dt_final[, Mean_ur]
    y_var_ci <- copy_dt_final[, Se_ur]
    par(mar = c(8,4,2,0), oma = c(0,0,0,0))
    plot(
        x_var,
        y_var,
        ylim = c(0, max(y_var + y_var_ci) + 0.01),
        col = "black",
        pch = 21, bg = my_col,
        xaxt = 'n',
        xlab = "",
        ylab = "Unassignment rate (%)",
        frame.plot = TRUE)

    y_down <- y_var - y_var_ci
    y_down[y_down == 0] <- -10e-5
    y_up <- y_var + y_var_ci
    y_up[y_up == 0] <- 10e-5

    arrows(
        x0 = x_var,
        y0 = y_down,
        x1 = x_var,
        y1 = y_up,
        code = 3,
        angle = 90,
        length = 0.05)

    par(new=TRUE)
    plot(
        x_var,
        y_var,
        ylim = c(0, max(y_var + y_var_ci) + 0.01),
        col = "black",
        pch = 21, bg = my_col,
        xaxt = 'n', xlab = "", ylab = "")
    axis(
        1,
        at = seq(
            1, (nrow(copy_dt_final) /
                    length(copy_dt_final[, unique(Decision)]))),
        labels = copy_dt_final[, unique(`Feature Combination`)],
        cex.axis = 0.5,
        las = 2)

    for (i in seq_along(sig_asterisk)){
        ## Horizontal bar
        segments(
            x0 = x_var_sig[i] + 0.05,
            y0 = (max(y_var + y_var_ci) + 0.01) * 0.80,
            x1 = x_var_sig[i] + 1 - 0.05,
            y1 = (max(y_var + y_var_ci) + 0.01) * 0.80)

        ## Vertical bars
        segments(
            x0 = x_var_sig[i] + 0.05,
            y0 = (max(y_var + y_var_ci) + 0.01) * 0.80,
            x1 = x_var_sig[i] + 0.05,
            y1 = (max(y_var + y_var_ci) + 0.01) * 0.80)
        segments(
            x0 = x_var_sig[i] + 1 - 0.05,
            y0 = (max(y_var + y_var_ci) + 0.01) * 0.80,
            x1 = x_var_sig[i] + 1 - 0.05,
            y1 = (max(y_var + y_var_ci) + 0.01) * 0.80)

        ## Significance asterisk
        text(
            x = (x_var_sig[i] + x_var_sig[i] + 1) / 2,
            y = (max(y_var + y_var_ci) + 0.01) * 0.83,
            labels = sig_asterisk[i])
    }

    ## Compound legend
    legend(
        "topright",
        pch = 21,
        legend = decision_order,
        col = my_col,
        pt.bg = my_col,
        bty = "n",
        pt.cex = 1,
        cex = 1.0,
        text.col = "black",
        horiz = FALSE,
        inset = c(0.01, 0.01))

    legend(
        "topright",
        pch = 21,
        legend = decision_order,
        col = "black",
        bty = "n",
        pt.cex = 1,
        cex = 1.0,
        text.col = "black",
        horiz = FALSE,
        inset = c(0.01, 0.01))

    p3 <- recordPlot()

    ## Significance testing for unassignment accuracy plot
    sig_asterisk <- rep(
        "",
        length(dt_original[, unique(`Feature Combination`)]) - 1)

    for (i in seq_along(sig_asterisk)) {
        x_1 <- dt_original[
            Decision == test_decision &
                `Feature Combination` == unique(`Feature Combination`)[i]
            , Unassignment_accuracy]
        x_2 <- dt_original[
            Decision == test_decision &
                `Feature Combination` == unique(`Feature Combination`)[i+1]
            , Unassignment_accuracy]
        if (!(all(x_1 %in% c(NaN, 0))) & !(all(x_2 %in% c(NaN, 0)))) {
            ttest <- t.test(
                dt_original[
                    Decision == test_decision &
                        `Feature Combination` == unique(
                            `Feature Combination`)[i]
                    , Unassignment_accuracy],
                dt_original[
                    Decision == test_decision &
                        `Feature Combination` == unique(
                            `Feature Combination`)[i+1]
                    , Unassignment_accuracy],
                alternative = "two.sided",
                paired = FALSE,
                var.equal = FALSE,
                conf.level = 0.95)
            if (ttest$p.value < 0.05) {
                sig_asterisk[i] <- "*"
            }
            no_graph <- FALSE
        } else {
            no_graph <- TRUE
        }
    }

    if (no_graph == FALSE) {
        ## Asterisk vector: either all asterisks, all n.s., starts with n.s. or
        ## starts with asterisk
        ## Find the index of the first n.s.
        stop_var <- 0
        idx <- 0
        for (i in seq_along(sig_asterisk)) {
            if (stop_var == 0 & sig_asterisk[i] == "") {
                stop_var <- 1
                idx <- i
            }
        }

        ##
        if (idx == 1) {
            sig_asterisk <- character()
        } else if (idx > 1) {
            sig_asterisk <- sig_asterisk[seq_len((idx-1))]
        }
        idx <- length(sig_asterisk)

        x_var <- rep(
            seq(
                1, (
                    nrow(copy_dt_final) /
                        length(copy_dt_final[, unique(Decision)]))),
            each = length(copy_dt_final[, unique(Decision)]))
        y_var <- copy_dt_final[, Mean_ua]
        y_var_ci <- copy_dt_final[, Se_ua]
        par(mar = c(8,4,2,0), oma = c(0,0,0,0))
        if (any(is.na(y_var))) {
            ylim_up <- 100 + 10
        } else {
            ylim_up <-(max(y_var + y_var_ci) + 0.01)
        }
        plot(
            x_var,
            y_var,
            ylim = c(0, ylim_up),
            col = "black",
            pch = 21, bg = my_col,
            xaxt = 'n',
            xlab = "",
            ylab = "Unassignment accuracy (%)",
            frame.plot = TRUE)

        y_down <- y_var - y_var_ci
        y_down[y_down == 0] <- -10e-5
        y_down[is.na(y_down)] <- -10e-5
        y_up <- y_var + y_var_ci
        y_up[y_up == 0] <- 10e-5
        y_up[is.na(y_up)] <- 10e-5

        arrows(
            x0 = x_var,
            y0 = y_down,
            x1 = x_var,
            y1 = y_up,
            code = 3,
            angle = 90,
            length = 0.05)

        suppressWarnings(par(new=TRUE))
        plot(
            x_var,
            y_var,
            ylim = c(0, ylim_up),
            col = "black",
            pch = 21, bg = my_col,
            xaxt = 'n', xlab = "", ylab = "")
        suppressWarnings(
            axis(
                1,
                at = seq(
                    1, (nrow(copy_dt_final) /
                            length(copy_dt_final[, unique(Decision)]))),
                labels = copy_dt_final[, unique(`Feature Combination`)],
                cex.axis = 0.5,
                las = 2)
        )

        if (!(any(is.na(y_var)))) {
            for (i in seq_along(sig_asterisk)){
                ## Horizontal bar
                segments(
                    x0 = x_var_sig[i] + 0.05,
                    y0 = ylim_up * 0.80,
                    x1 = x_var_sig[i + 1] - 0.05,
                    y1 = ylim_up * 0.80)

                ## Vertical bars
                segments(
                    x0 = x_var_sig[i] + 0.05,
                    y0 = ylim_up * 0.80,
                    x1 = x_var_sig[i] + 0.05,
                    y1 = ylim_up * 0.80)
                segments(
                    x0 = x_var_sig[i + 1] - 0.05,
                    y0 = ylim_up * 0.80,
                    x1 = x_var_sig[i + 1] - 0.05,
                    y1 = ylim_up * 0.80)

                ## Significance asterisk
                text(
                    x = (x_var_sig[i] + x_var_sig[i + 1]) / 2,
                    y = ylim_up * 0.83,
                    labels = sig_asterisk[i])
            }
        }

        ## Compound legend
        legend(
            "topright",
            pch = 21,
            legend = decision_order,
            col = my_col,
            pt.bg = my_col,
            bty = "n",
            pt.cex = 1,
            cex = 1.0,
            text.col = "black",
            horiz = FALSE,
            inset = c(0.01, 0.01))

        legend(
            "topright",
            pch = 21,
            legend = decision_order,
            col = "black",
            bty = "n",
            pt.cex = 1,
            cex = 1.0,
            text.col = "black",
            horiz = FALSE,
            inset = c(0.01, 0.01))
    } else if (no_graph == TRUE){
        x_var <- rep(
            seq(
                1, (
                    nrow(copy_dt_final) /
                        length(copy_dt_final[, unique(Decision)]))),
            each = length(copy_dt_final[, unique(Decision)]))
        y_var <- copy_dt_final[, Mean_ua]
        y_var_ci <- copy_dt_final[, Se_ua]
        par(mar = c(8,4,2,0), oma = c(0,0,0,0))
        if (any(is.na(y_var))) {
            ylim_up <- 100 + 10
        } else {
            if (all(is.na(c(y_var + y_var_ci)))) {
                ylim_up <- 100
            } else {
                ylim_up <-(max(y_var + y_var_ci) + 0.01)
            }
        }
        plot(
            x_var,
            y_var,
            ylim = c(0, ylim_up),
            col = "black",
            pch = 21, bg = my_col,
            xaxt = 'n',
            xlab = "",
            ylab = "Unassignment accuracy (%)",
            frame.plot = TRUE)

        suppressWarnings(
            axis(
                1,
                at = seq(
                    1, (nrow(copy_dt_final) /
                            length(copy_dt_final[, unique(Decision)]))),
                labels = copy_dt_final[, unique(`Feature Combination`)],
                cex.axis = 0.5,
                las = 2)
        )

        ## Compound legend
        legend(
            "topright",
            pch = 21,
            legend = decision_order,
            col = my_col,
            pt.bg = my_col,
            bty = "n",
            pt.cex = 1,
            cex = 1.0,
            text.col = "black",
            horiz = FALSE,
            inset = c(0.01, 0.01))

        legend(
            "topright",
            pch = 21,
            legend = decision_order,
            col = "black",
            bty = "n",
            pt.cex = 1,
            cex = 1.0,
            text.col = "black",
            horiz = FALSE,
            inset = c(0.01, 0.01))
    }
    p4 <- recordPlot()

    return(list(
        identification_acc_all = p1,
        identification_acc_best = p2,
        unassignment_rate_best = p3,
        unassignment_acc_best = p4))
}
