#' nb_export_labelled_file
#'
#' @description Wrapper function to export a labelled peak file to a text file.
#'
#' @usage
#' nb_export_labelled_file(labelled_file, filename)
#'
#' @param labelled_file Labelled peak file.
#' @param filename Name and path of output text file (ending in *.txt)
#'
#' @details
#' \tabular{lll}{
#' labelled_file \tab \tab Data.table. \cr
#' filename \tab \tab String. \cr
#' }
#'
#' @examples
#' \dontrun{
#' See batl-Introduction vignette
#' }
#'
#' @export nb_export_labelled_file
#'

nb_export_labelled_file <- function(labelled_file, filename) {

    if (!(is.data.frame(labelled_file))) {
        stop("labelled_file must be a data.frame object")
    }
    if (!(is.character(filename))) {
        stop("filename must be a string.")
    }
    if (grepl(".txt$", filename) == FALSE) {
        stop("filename must end with a '.txt' extension.")
    }

    fwrite(
        x = labelled_file,
        file = filename,
        sep = "\t",
        row.names = FALSE,
        col.names = TRUE)
}
