#' nb_export_library
#'
#' @description Wrapper function to export a data.table library to a text file.
#'
#' @usage
#' nb_export_library(library, filename)
#'
#' @param library Data.table library of labelled peaks.
#' @param filename Name and path of output text file (ending in *.txt)
#'
#' @details
#' \tabular{lll}{
#' nb_model \tab \tab Data.table. \cr
#' filename \tab \tab String. \cr
#' }
#'
#' @examples
#' \dontrun{
#' See batl-Introduction vignette
#' }
#'
#' @export nb_export_library
#'

nb_export_library <- function(library, filename) {

    if (!(is.data.frame(library))) {
        stop("library must be a data.frame/data.table object.")
    }
    if (!(is.character(filename))) {
        stop("filename must be a string.")
    }
    if (grepl(".txt$", filename) == FALSE) {
        stop("filename must end with a '.txt' extension.")
    }

    ## Error-checking
    orig_nrow <- nrow(library)
    test_nrow <- nrow(unique(library))
    if (orig_nrow != test_nrow) {
        stop(paste0(
            "The library contains redundant rows. Ensure that a peak is ",
            "defined by a unique Filename, Sample.Index, Sample.Name, and ",
            "Index"))
    }

    library <- as.data.table(library)
    fwrite(
        x = library,
        file = filename,
        sep = "\t",
        row.names = FALSE,
        col.names = TRUE)
}
