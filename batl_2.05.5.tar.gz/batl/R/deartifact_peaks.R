#' deartifact_peaks
#'
#' @description Annotate a vector of qsessions with
#' in-source sphingolipid lipid artifacts (dehydrations, multimerization,
#' deglycosylations, etc.) and isotopes.
#' A "Retention Time" or "Retention.Time" column must be present to work.
#'
#' @usage
#' deartifact_peaks(
#'     filenames,
#'     category,
#'     Q1_tolerance,
#'     retention_tolerance,
#'     exceptions,
#'     ...)
#'
#' @param filenames Vector of peak files or a single peak file data frame.
#' @param category LIPID MAPS 2-letter string denoting the lipid category.
#' Currently supports "SP" or "GP".
#' @param Q1_tolerance m/z tolerance of mass spectrometer. '0.5' means +/- 0.5
#' m/z units above and below the target m/z.
#' @param retention_tolerance Number of significant digits to match peaks by
#' shared retention time. 2 is the default.
#' @param exceptions Keyword exceptions in the "Mass Info" column indicating
#' rows to exclude from labelling.
#' @param ... Advanced parameter to customize the 'annotation_table'.
#'
#' @format \tabular{lll}{
#' filenames \tab \tab Character string/vector or a data frame. \cr
#' category \tab \tab 2-character string. \cr
#' Q1_tolerance \tab \tab Numeric. \cr
#' retention_tolerance \tab \tab Integer. \cr
#' ... 3 column data.table named "Delta_q1", "Insource_annotation", and "Type".
#' Delta_q1 is the parent ion m/z of the annotation from Insource_annotation.
#' Type is an integer used to compute all compound annotations. Compound
#' annotations are only generated from annotations with unique integer Types.}
#'
#' @return
#' List of output files with an additional column "Insource_annotation"
#' indicating any in-source artifacts/isotopes.
#'
#' @examples
#' \dontrun{
#' See batl-Introduction vignette
#' }
#'
#' @export deartifact_peaks
#'

deartifact_peaks <- function(
    filenames, category, Q1_tolerance, retention_tolerance, exceptions, ...) {

    ## Error-checking
    if (missing(category)) {
        stop(paste0(
            "Must specify a 2-letter LIPID MAPS code denoting the category. ",
            "Currently supports:\n",
            "'FA' for fatty acyls (isotopes) \n",
            "'GL' for glycerolipids (isotopes) \n",
            "'GP' for glycerophospholipids (isotopes)\n",
            "'SP' for sphingolipids (isotopes, dehydrations, deglycosylations,",
            " dimers)\n",
            "'ST' for sterol lipids (isotopes)\n",
            "'PR' for prenol lipids (isotopes)\n",
            "'SL' for saccharolipids (isotopes)\n",
            "'PK' for polyketides (isotopes)"))
    }
    if (!(category %in% c("FA", "GL", "GP", "SP", "ST", "PR", "SL", "PK"))) {
        stop(paste0(
            "Category must be\n",
            "'FA' for fatty acyls (isotopes) \n",
            "'GL' for glycerolipids (isotopes) \n",
            "'GP' for glycerophospholipids (isotopes)\n",
            "'SP' for sphingolipids (isotopes, dehydrations, deglycosylations,",
            " dimers)\n",
            "'ST' for sterol lipids (isotopes)\n",
            "'PR' for prenol lipids (isotopes)\n",
            "'SL' for saccharolipids (isotopes)\n",
            "'PK' for polyketides (isotopes)"))
    }
    if (length(category) != 1) {
        stop("Must specify a single category.")
    }
    if (missing(Q1_tolerance)) {
        stop("Must specify a Q1_tolerance value")
    }
    if (!(is.numeric(Q1_tolerance))) {
        stop("Q1_tolerance must be numeric.")
    }
    if (missing(retention_tolerance)) {
        retention_tolerance <- 2
    }
    if (!(retention_tolerance %% 1 == 0) | retention_tolerance < 0) {
        stop("retention_tolerance must be a whole number.")
    }
    if (missing(exceptions)) {
        exceptions <- character()
    }

    ## Capture unevaluated expression about the annotation table
    params <- list(...)
    if ("annotation_table" %in% names(params)) {
        anno_dt <- params[[which(names(params) %in% "annotation_table")]]
    } else {
        anno_dt <- deartifact_peaks_anno_table(category = category)
    }

    ## Check for the first 4-5 mandatory columns in the peak files
    mandatory_cols <- c(
        "Index", "Sample.Index", "Sample.Name", "Mass.Info")

    if (is.character(filenames)) {
        for (kFile in seq_along(filenames)) {
            loaded <- nb_label_peaks_load(filename = filenames[kFile])
            colnames(loaded) <- gsub("\\s+", ".", colnames(loaded))
            check_vec <- mandatory_cols %in% colnames(loaded)
            if (any(check_vec == FALSE)) {
                stop(paste0(
                    "The following column(s) are missing in the peak files:\n",
                    paste0(mandatory_cols[check_vec == FALSE], collapse = ", ")))
            }
        }

        output <- vector("list", length = length(filenames))
        for (kFile in seq_along(output)) {
            output[[kFile]] <- deartifact_peaks_deartifact(
                filename = filenames[kFile],
                anno_dt = anno_dt,
                category = category,
                Q1_tolerance = Q1_tolerance,
                retention_tolerance = retention_tolerance,
                exceptions = exceptions)
        }
    } else if (is.data.frame(filenames)) {
        filenames <- as.data.table(filenames)
        colnames(loaded) <- gsub("\\s+", ".", colnames(filenames))
        check_vec <- mandatory_cols %in% colnames(filenames)
        if (any(check_vec == FALSE)) {
            stop(paste0(
                "The following column(s) are missing in the peak files:\n",
                paste0(mandatory_cols[check_vec == FALSE], collapse = ", ")))
        }
        output <- deartifact_peaks_deartifact(
            filename = filenames,
            anno_dt = anno_dt,
            category = category,
            Q1_tolerance = Q1_tolerance,
            retention_tolerance = retention_tolerance,
            exceptions = exceptions)
    } else {
        stop("filenames must be a filename string or a data table of peaks.")
    }

    return(output)
}
