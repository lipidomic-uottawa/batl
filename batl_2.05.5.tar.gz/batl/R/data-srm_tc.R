#' Targeted lipidomics dataset of mouse temporcal cortex
#'
#' Data generated from ...
#'
#'
#' @docType data
#'
#' @usage data(srm_tc)
#'
#' @format A data table object.
#'
#' @keywords datasets
#'
#' @examples
#' data(srm_tc)
#'
#'
"srm_tc"
