#' nb_model_scores
#'
#' @description Flatten all \emph{k}-fold cross validation list
#' results and assess model performance.
#'
#' @usage
#' nb_model_scores(model_assignments)
#'
#' @param model_assignments Cross validation assignments outputted from
#' \emph{nb_label_peaks} with full_output set to TRUE.
#'
#' @return
#' Data table object of \emph{k}-fold cross validation scores.
#'
#' @examples
#' \dontrun{
#' See batl-Introduction vignette
#' }
#' @export nb_model_scores
#'

nb_model_scores <- function(model_assignments) {

    ## Null strategy to pass R CMD check
    Fold <- `Feature Combination` <- NULL

    ## Decision algorithms used
    my_decision <- colnames(model_assignments[[1]])[
        which(colnames(model_assignments[[1]]) %in% c(
            "MAP_dup",
            "MAP_nodup",
            "MWBM"))]

    ## Initialize list of matrices (number of feature combinations by folds)
    scores <- vector(
        "list",
        length = length(model_assignments[[1]][, unique(Fold)]))
    scores <- lapply(seq_len(
        length(model_assignments)),
        function(x) copy(scores))

    ## Fill list
    for (kComb in seq_along(model_assignments)) {
        for (kFold in model_assignments[[kComb]][, unique(Fold)]) {
            temp <- utility_accuracy(
                model_assignments[[kComb]][Fold == kFold],
                decision = my_decision)
            feature_combination <- names(model_assignments)[kComb]
            temp <- cbind(temp, kFold, feature_combination)
            scores[[kComb]][[kFold]] <- temp
        }
    }

    ## Flatten list of lists to data table
    scores <- lapply(scores, function(x) do.call("rbind", x))
    scores <- do.call("rbind", scores)
    scores <- as.data.table(scores)

    ## Clean up data table names and convert characters to numerics
    setnames(scores, "feature_combination", "Feature Combination")

    ## Bypass integer conversion warnings with a holdout dataset
    suppressWarnings(check <- any(is.na(as.numeric(scores[, kFold]))))

    if (check == TRUE) {
        scores[, kFold := NULL]
        scores[, kFold := NA_integer_]
    }
    for (kCol in seq(2, 8)) {
        set(scores,
            j = kCol,
            value = as.integer(scores[[kCol]]))
    }
    scores[
        , "Number of Features" := 1 + lengths(regmatches(
            `Feature Combination`, gregexpr("_", `Feature Combination`)))]

    return(scores)
}
