## Base annotation table
deartifact_peaks_anno_table <- function(category) {
    if (category == "SP") {
        anno_dt <- data.table(
            Delta_q1 = c(
                1,
                2,
                3,
                4,
                -18,
                -36,
                -162,
                -324,
                -486),
            Insource_annotation = c(
                "+1 isotope",
                "+2 isotope",
                "+3 isotope",
                "+4 isotope",
                "-1 dehydration",
                "-2 dehydration",
                "-1 deglycosylation",
                "-2 deglycosylation",
                "-3 deglycosylation"),
            Type = c(
                0L,
                0L,
                0L,
                0L,
                1L,
                1L,
                2L,
                2L,
                2L))
    } else if (category %in% c("FA", "GL", "GP", "SP", "ST", "PR", "SL","PK")) {
        anno_dt <- data.table(
            Delta_q1 = c(
                1,
                2,
                3,
                4),
            Insource_annotation = c(
                "+1 isotope",
                "+2 isotope",
                "+3 isotope",
                "+4 isotope"),
            Type = c(
                0L,
                0L,
                0L,
                0L))
    }
    return(anno_dt)
}

## Expanded annotations

#' @importFrom data.table rbindlist
deartifact_peaks_anno_expand <- function(anno_dt) {

    ## Null strategy to pass R CMD check
    Type <- Delta_q1 <- Insource_annotation <- NULL

    idx <- vector("list", length = nrow(anno_dt))
    for (init in seq_len(nrow(anno_dt))) {
        idx[[init]] <- matrix(c(init, anno_dt[init, Type]), ncol = 2)
        for (i in seq_len(nrow(anno_dt))) {

            if (i != init & !(anno_dt[i, Type] %in% idx[[init]][, 2])) {
                idx[[init]] <- rbind(idx[[init]], c(i, anno_dt[i, Type]))
            }
        }
    }

    ## Find all subset combinations of annotations
    ## Loop to initialize list
    init_idx <- 0
    for (i in seq_along(idx)) {
        max_iter <- nrow(idx[[i]]) - 1
        if (max_iter >= 2) {
            for (j in seq(2, max_iter)) {
                init_idx <- init_idx + 1
            }
        }
    }
    ## Find all subset combinations
    idx_extra <- vector("list", length = init_idx)
    for (i in seq_along(idx)) {
        max_iter <- nrow(idx[[i]]) - 1
        if (max_iter >= 2) {
            for (j in seq(2, max_iter)) {
                idx_extra[[i]] <- as.data.table(t(combn(idx[[i]][, 1], j)))
            }
        }
    }
    idx_extra <- rbindlist(idx_extra)
    idx_extra <- apply(
        idx_extra, 1, function(x) paste0(sort(x), collapse = " "))
    idx_extra <- unique(idx_extra)
    idx_extra_list <- vector("list", length = length(idx_extra))
    for (i in seq_along(idx_extra_list)) {
        idx_extra_list[[i]] <- matrix(as.numeric(
            strsplit(idx_extra[i], " ")[[1]]), ncol = 1)
    }

    ## Merge lists
    idx <- c(idx, idx_extra_list)

    ## Sort and remove duplicates
    for (i in seq_along(idx)) {
        idx[[i]] <- idx[[i]][order(idx[[i]][,1]),, drop = FALSE]
    }
    idx <- unique(idx)

    ## Create annotations from indices
    add_anno <- vector("list", length = length(idx))
    for (i in seq_along(idx)) {
        add_anno[[i]] <- data.table(
            Delta_q1 = anno_dt[idx[[i]][, 1], sum(Delta_q1)],
            Insource_annotation = anno_dt[idx[[i]][, 1], paste0(
                Insource_annotation, collapse = "; ")],
            Type = 0L)
    }
    add_anno <- do.call("rbind", add_anno)

    ## Combine in-source modification combinations with base combinations
    anno_dt <- rbind(anno_dt, add_anno)
    anno_dt[, "Type" := NULL]

    return(anno_dt)
}

## Main deartifacting/isotoping function
deartifact_peaks_deartifact <- function(
    filename, anno_dt, category, Q1_tolerance, retention_tolerance,
    exceptions) {

    ## Null strategy to pass R CMD check
    Mass.Info <- Q1 <- Q3 <- Delta_q1 <- Interest <- Interest_round_up <- NULL
    Interest_round_down <- i.Q1 <- i.Q3 <- Q1_max <- i.Q1_min <- NULL
    Q1_min <- i.Q1_max <- Delta_q1_min <- Delta_q1_max <- NULL
    Insource_annotation <- Delta_q1_mono_min <- Delta_q1_mono_max <- NULL
    Check <- Check_multimer_min <- Check_multimer_reg <- NULL
    Check_multimer_max <- Multimer <- Index <- Sample.Index <- NULL
    Sample.Name <- NULL

    ## Load file if not already a data table
    if (is.character(filename)) {
        filename <- nb_label_peaks_load(filename = filename)
    }
    original_colnames <- c(colnames(filename), "Insource_annotation")

    ## All annotations based on 'Retention.Time'
    if (!(all(
        c("Retention.Time", "Retention Time") %in% colnames(filename)))) {
        if ("Retention.Time" %in% colnames(filename)) {
            feature <- "Retention.Time"
        } else if ("Retention Time" %in% colnames(filename)) {
            feature <- "Retention Time"
        }
    } else {
        stop("Retention.Time or Retention Time column must be present.")
    }

    ## Copy input file to maintain exactly the same output + barcode column
    filename_original <- copy(filename)

    ## Remove rows based on exceptions
    if (length(exceptions) > 0L) {
        frow1 <- nrow(filename)
        filename <- filename[!(Mass.Info %in% exceptions)]
        frow2 <- nrow(filename)
        frow2 <- frow1 - frow2
        if (frow2 != 0) {
            message(paste0(
                "Filtered ", frow2, "/", frow1,
                " rows based on the exceptions ",
                "parameter."))
        }
    }

    ## Split Mass.Info
    filename[, c("Q1", "Q3") := tstrsplit(Mass.Info, "/")]
    if (any(is.na(filename[, Mass.Info]))) {
        stop(paste0(
            "Please ensure the Mass Info column follows the format: ",
            "XXX.X / YYY.Y\n",
            "Any strings such as as 'TIC' (total ion chromatogram) ",
            "or 'ADC' (analog digital converter) should be filtered out ",
            "using the exceptions parameter."))
    }
    filename[, Q1 := as.numeric(Q1)]
    filename[, Q3 := as.numeric(Q3)]

    ## Expand annotation table to allow for all possible compound annotations
    anno_dt <- deartifact_peaks_anno_expand(anno_dt = anno_dt)

    ## Add minimum/maximum boundaries for foverlaps
    anno_dt[, "Delta_q1_min" := Delta_q1]
    anno_dt[, "Delta_q1_max" := Delta_q1]

    ## Round retention time feature to the tolerance
    setnames(filename, feature, "Interest")
    filename[
        , "Interest_round_up" := round(
            Interest,
            digits = retention_tolerance) +
            10^(-(retention_tolerance + 1))]
    filename[
        , "Interest_round_down" := round(
            Interest,
            digits = retention_tolerance) -
            10^(-(retention_tolerance + 1))]

    ## Find upper and lower Q1 bounds
    filename[, "Q1_min" := as.numeric(Q1) - Q1_tolerance]
    filename[, "Q1_max" := as.numeric(Q1) + Q1_tolerance]

    ## Determine whether there are any peaks within a sample that have the same
    ## rounded RT
    filename_sub_1 <- copy(unique(
        filename, by = c("Index", "Sample.Index", "Sample.Name")))
    filename_sub_1 <- filename_sub_1[
        !(is.na(Interest_round_up)) & !(is.na(Interest_round_down))]
    filename_sub_2 <- copy(filename_sub_1)
    setkey(
        filename_sub_1,
        "Sample.Index",
        "Sample.Name",
        "Interest_round_down",
        "Interest_round_up")
    setkey(
        filename_sub_2,
        "Sample.Index",
        "Sample.Name",
        "Interest_round_down",
        "Interest_round_up")
    filename_sub_1 <- foverlaps(filename_sub_1, filename_sub_2, type = "any")
    filename_sub_1 <- filename_sub_1[Q1 != i.Q1]

    ## Ensure any matching peaks based on retention time have the same Q3
    filename_sub_1 <- filename_sub_1[Q3 == i.Q3]

    ## Determine what the difference in Q1 m/z is:
    filename_sub_1[, "Delta_q1" := as.numeric(Q1) - as.numeric(i.Q1)]
    filename_sub_1[
        , "Delta_q1_min" := min(
            c((Q1_max - i.Q1_min), (Q1_min - i.Q1_max)))
        , by = seq_len(nrow(filename_sub_1))]
    filename_sub_1[
        , "Delta_q1_max" := max(
            c((Q1_max - i.Q1_min), (Q1_min - i.Q1_max)))
        , by = seq_len(nrow(filename_sub_1))]

    ## Check if there exists any annotations
    if (nrow(filename_sub_1) == 0) {
        message("No in-source artifacts/isotopes found.")
        message("No in-source artifacts/isotopes found.")
        setnames(filename, "Interest", feature)
        return(return)
    }

    filename_sub_1 <- filename_sub_1[
        , c(
            "Index",
            "i.Index",
            "Sample.Index",
            "Sample.Name",
            "Q1",
            "Q3",
            "i.Q1",
            "i.Q3",
            "Delta_q1",
            "Delta_q1_min",
            "Delta_q1_max")]

    ## Merge peaks to be annotated with annotation table
    setkey(filename_sub_1, Delta_q1_min, Delta_q1_max)
    setkey(anno_dt, Delta_q1_min, Delta_q1_max)
    filename_sub_1 <- foverlaps(filename_sub_1, anno_dt, type = "any")

    ## Find smallest and largest Q1s of the reference mono-isotopic peaks
    filename_sub_1[
        , "Delta_q1_mono_min" := min(as.numeric(Q1), as.numeric(i.Q1)),
        by = seq_len(nrow(filename_sub_1))]
    filename_sub_1[
        , "Delta_q1_mono_max" := max(as.numeric(Q1), as.numeric(i.Q1)),
        , by = seq_len(nrow(filename_sub_1))]

    ## Mono peak is the one with smallest delta Q1 for isotope annotations
    filename_sub_1[
        !(is.na(Insource_annotation)) & Delta_q1 > 0
        , Insource_annotation := paste0(
            Insource_annotation,
            " of peak: ",
            Delta_q1_mono_min,
            " / ",
            Q3)]

    ## Max peak is the one with biggest delta Q1 for remaining annotations
    filename_sub_1[
        !(is.na(Insource_annotation)) & Delta_q1 < 0
        , Insource_annotation := paste0(
            Insource_annotation,
            " of peak: ",
            Delta_q1_mono_max,
            " / ",
            Q3)]

    ## Find multimers
    if (category %in% c("SP")) {
        filename_sub_1[, "Check" := NA_integer_]
        filename_sub_2[, "Check_multimer_min" := NA_real_]
        filename_sub_2[, "Check_multimer_reg" := NA_real_]
        filename_sub_2[, "Check_multimer_max" := NA_real_]
        filename_sub_1[
            (Delta_q1_mono_max / as.numeric(Q1) < 2.05) &
                (Delta_q1_mono_max / as.numeric(Q1) > 1.95)
            , Check := 2L]
        filename_sub_1[
            (Delta_q1_mono_max / as.numeric(Q1) < 3.05) &
                (Delta_q1_mono_max / as.numeric(Q1) > 2.95)
            , Check := 3L]
        filename_sub_1[
            (Delta_q1_mono_max / as.numeric(Q1) < 4.05) &
                (Delta_q1_mono_max / as.numeric(Q1) > 3.95)
            , Check := 4L]
        filename_sub_1[
            !(is.na(Check))
            , Check_multimer_min :=
                abs(Delta_q1_mono_max - Check * (
                    as.numeric(Q1) - Q1_tolerance))]
        filename_sub_1[
            !(is.na(Check))
            , Check_multimer_reg :=
                abs(Delta_q1_mono_max - Check * as.numeric(Q1))]
        filename_sub_1[
            !(is.na(Check))
            , Check_multimer_max :=
                abs(Delta_q1_mono_max - Check * (
                    as.numeric(Q1) + Q1_tolerance))]
        filename_sub_1[, "Multimer" := FALSE]
        filename_sub_1[
            Check_multimer_min <= 1 |
                Check_multimer_reg <= 1 |
                Check_multimer_max <= 1
            , "Multimer" := TRUE]

        filename_sub_1[
            Multimer == TRUE & is.na(Insource_annotation)
            , Insource_annotation := paste0(
                "+",
                Check,
                " multimer of peak: ",
                Delta_q1_mono_max,
                " / ",
                Q3)]
        filename_sub_1[
            Multimer == TRUE & !(is.na(Insource_annotation))
            , Insource_annotation := paste0(
                Insource_annotation,
                "; ",
                "+",
                Check,
                " multimer of peak: ",
                Delta_q1_mono_max,
                " / ",
                Q3)]
        filename_sub_1[
            , c("Check",
                "Check_multimer_min",
                "Check_multimer_reg",
                "Check_multimer_max",
                "Multimer") := NULL]
    }

    ## Merge annotations with original data table of assignments
    filename_sub_1 <- filename_sub_1[
        , c(
            "Insource_annotation",
            "Index",
            "Sample.Index",
            "Sample.Name",
            "Q1",
            "Q3")]

    ## Merge peaks with multiple annotations
    filename_sub_1 <- filename_sub_1[!(is.na(Insource_annotation))]
    filename_sub_1 <- unique(
        filename_sub_1
        , by = c(
            "Index", "Sample.Index", "Sample.Name",
            "Q1", "Q3", "Insource_annotation"))
    filename_sub_1[
        , Insource_annotation := paste(Insource_annotation, collapse = "; ")
        , by = c("Index", "Sample.Index", "Sample.Name", "Q1", "Q3")]
    filename_sub_1 <- unique(
        filename_sub_1,
        by = c("Index", "Sample.Index", "Sample.Name", "Q1", "Q3"))

    setkey(filename_sub_1, Index, Sample.Index, Sample.Name, Q1, Q3)
    setkey(filename, Index, Sample.Index, Sample.Name, Q1, Q3)

    filename[, c("Interest_round_up", "Interest_round_down") := NULL]
    filename <- merge(filename, filename_sub_1, all.x = TRUE)
    filename[, c("Q1_min", "Q1_max") := NULL]
    setnames(filename, "Interest", feature)

    ## Rename columns back to original
    filename[, c("Q1", "Q3") := NULL]

    setcolorder(filename, original_colnames)

    ## Assign annotations to the original peak file
    setkey(filename_original, Index, Sample.Index, Sample.Name)
    setkey(filename, Index, Sample.Index, Sample.Name)
    filename_original <- merge(
        filename_original,
        filename[
            , c("Index", "Sample.Index", "Sample.Name", "Insource_annotation")],
        all.x = TRUE)

    colnames(filename_original) <- gsub(
        ".", " ", fixed = TRUE, colnames(filename_original))

    return(filename_original)
}
