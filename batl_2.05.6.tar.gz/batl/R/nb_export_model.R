#' nb_export_model
#'
#' @description Wrapper function to export a BATL model to a tab-delimited text
#' file from \code{\link{nb_build_model}}.
#'
#' @usage
#' nb_export_model(nb_model, filename)
#'
#' @param nb_model List containing data table model and meta information.
#' @param filename Name and path of output text file (ending in *.txt)
#'
#'
#' @examples
#' \dontrun{
#' See batl-Introduction vignette for details
#' }
#'
#' @importFrom data.table fwrite
#' @export nb_export_model
#'
nb_export_model <- function(nb_model, filename) {

    ## Null strategy to pass R CMD check
    Barcode <- NULL

    ## Error-checking
    if (missing(nb_model)) {
        stop("Must specify a single nb_model.")
    }
    if (length(nb_model) != 2) {
        stop("Length of nb_model must equal 2.")
    }
    if (any(!(c("Model", "Meta_information") %in% names(nb_model)))) {
        stop(paste(
            "'Model' and 'Meta_information' must be",
            "the list names of nb_model"))
    }
    if (missing(filename)) {
        stop("Must specify a filename")
    }
    if (!(is.character(filename))) {
        stop("filename must be a string.")
    }
    if (grepl(".txt$", filename) == FALSE) {
        stop("filename must end with a '.txt' extension.")
    }

    ## Export meta information as a header
    fwrite(
        x = as.data.table(nb_model$Meta_information),
        file = filename,
        quote = FALSE,
        sep = "\t",
        row.names = FALSE,
        col.names = FALSE)

    ## Column header to first row of model
    first_row <- as.matrix(nb_model$Model[1,])
    first_row[1,] <- names(nb_model$Model)
    first_row <- as.data.table(first_row)
    append_model <- rbind(first_row, nb_model$Model)
    append_model[, Barcode := as.character(Barcode)]

    ## Append data table below meta information
    fwrite(
        x = append_model,
        file = filename,
        quote = FALSE,
        sep = "\t",
        row.names = FALSE,
        col.names = FALSE,
        append = TRUE)
}
