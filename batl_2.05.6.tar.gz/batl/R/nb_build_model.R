#' nb_build_model
#'
#' @description Construct the naive Bayes model using the specified combination
#' of features or all feature subsets.
#'
#' @usage
#' nb_build_model(
#'     library,
#'     folds,
#'     features,
#'     exhaustive,
#'     decision,
#'     tolerance,
#'     parallel_cores,
#'     pseudocount,
#'     full_output)
#'
#' @param library Data table of labelled SRM data. See \emph{Details} for
#' formatting.
#' @param folds Number of folds in \emph{k}-fold cross validation.
#' @param features Vector of feature names shared in the peak file/library.
#' @param exhaustive Build and train models for all combinations of features.
#' Default is FALSE.
#' @param decision Decision algorithm. Default is "MWBM". Other options include
#' "MAP_dup", and "MAP_nodup". See \emph{Details} for more information.
#' @param tolerance Q1 and Q3 m/z tolerance for matching peaks to library
#' barcodes. m/z +/- 0.5 is the default.
#' @param parallel_cores Number of cores to enable parallel computing of
#' cross validation.
#' @param pseudocount Default is 0. For prior estimation.
#' @param full_output TRUE will return a data table of all possible assignments
#' during cross validation for model selection. Default is FALSE.
#'
#' @details
#' "library" (also known as the training set) must contain the following columns
#' in this order:
#' Filename, Sample.Index, Sample.Name, Index, Q1, Q3, Barcode, and all desired
#' peak features.
#'
#' decision = MWBM (maximum weighted bipartite matching) assigns lipid labels
#' by maximizing the joint log posterior probability of all peak assignments
#' within a transition.
#'
#' decision = MAP_dup assigns lipid labels based on the greatest posterior
#' probability. It is possible that two or more peaks within the same sample
#' will be assigned the same lipid identity, however.
#'
#' decision = MAP_nodup assigns lipid labels based on the greatest posterior
#' probability constrained such that the same lipid label will not be assigned
#' more than once within a sample.
#'
#' full_output = TRUE if you would like to analyze your cross validation
#' results from your personal training set using \emph{nb_model_scores}.
#'
#' @return
#' List of data tables for each feature combination, containing the priors,
#' likelihood parameters, posterior probability cutoffs, and assigned lipid
#' identity. Also includes
#' relevant meta information. When \emph{full_output} is TRUE, a list of all
#' peak assignments is returned and a list of all posterior cutoffs across
#' all cross validation folds.
#'
#' @examples
#' \dontrun{
#' See batl-Introduction vignette
#' }
#'
#' @importFrom data.table setnames foverlaps set .SD
#' @importFrom foreach foreach %dopar%
# #' @importFrom doParallel registerDoParallel
#' @importFrom doFuture registerDoFuture
#' @importFrom future plan
#' @importFrom parallel makeCluster stopCluster
#' @importFrom utils combn packageDescription
#' @importFrom stats ks.test var
#' @importFrom igraph graph.data.frame max_bipartite_match V E V<- E<-
#' @importFrom progressr with_progress progressor handlers
#'
#' @export nb_build_model

nb_build_model <- function(
    library, folds, features, exhaustive, decision, tolerance, parallel_cores,
    pseudocount, full_output) {

    ## Null strategy to pass R CMD check
    kFold <- Barcode <- Keep <- Mass.Info <- NULL

    ## Start time
    function_start <- Sys.time()

    if (missing(library)) {
        stop("library must be specified.")
    }
    if (any(colnames(library)[seq_len(6)] != c(
        "Filename", "Sample.Index", "Sample.Name", "Index", "Mass.Info",
        "Barcode"))) {
        stop(paste0(
            "The following columns are not present or in the following order:",
            "\n",
            "Filename Sample.Index Sample.Name Index Mass.Info ",
            "Barcode"))
    }

    ## Full output means all training data assignments are recorded
    if (missing(full_output)) {
        full_output <- FALSE
    } else if (!(is.logical(full_output))) {
        stop("full_output must be TRUE/FALSE.")
    }
    if (missing(folds)) {
        stop("folds must be specified (whole number > 1).")
    }
    if (folds %% 1 != 0) {
        stop("folds must be a whole number > 1.")
    }
    if (folds <= 1) {
        stop("folds must be greater than 1.")
    }
    if (missing(features)) {
        stop("features must be specified")
    }
    if (missing(exhaustive)) {
        exhaustive <- FALSE
    } else if (!(is.logical(exhaustive))) {
        stop("exhaustive must be TRUE/FALSE.")
    }

    ## Automatically specify a single core
    if (missing(parallel_cores)) {
        parallel_cores <- 1L
    }

    ## Ensure parallel cores is properly specified
    if (parallel_cores <= 0 |
        (
            ceiling(parallel_cores) != parallel_cores |
            floor(parallel_cores) != parallel_cores)) {
        stop("parallel_cores must be a whole number.")
    }

    if (missing(pseudocount)) {
        pseudocount <- 0
    }

    if (pseudocount < 0 | pseudocount %% 1 != 0) {
        stop("pseudocount must be a whole number.")
    }

    if (missing(tolerance)) {
        tolerance <- 0.5
    }

    ## If decision algorithm isn't specified, use the best one
    if (missing(decision)) {
        decision <- c("MWBM")
    }

    features <- gsub("\\s+", ".", features)
    if (!(all(features %in% colnames(library)))) {
        print_features <- features[!(features %in% colnames(library))]
        stop(paste0(
            "Not all specified features are present in the library/training ",
            "set. Missing the following:\n",
            paste0(print_features, collapse = "\n")))
    }

    ## Create list of feature combinations
    fcombinations <- nb_build_model_feature_combinations(
        exhaustive = exhaustive, features = features)

    ## Split Mass.Info column
    library <- as.data.table(library)
    idx_start <- which(colnames(library) == "Mass.Info") - 1
    library[, c("Q1", "Q3") := tstrsplit(gsub("\\s+", "", Mass.Info), "/")]
    library[, "Mass.Info" := NULL]
    idx_q13 <- (ncol(library)-1):ncol(library)
    setcolorder(
        library,
        c(seq_len(idx_start), idx_q13, seq((idx_start + 1), (idx_q13[1] - 1))))

    ## Remove "UNASSIGNED" Barcode because it is a collection of peaks with no
    ## identities. No point trying to model this barcode
    library[, "Keep" := TRUE]
    library[Barcode %in% c("UNASSIGNED", "NA", ""), Keep := FALSE]
    library <- library[Keep == TRUE]
    library[, "Keep" := NULL]

    ## Remove blank rows if these are somehow scanned in
    library <- library[!(apply(is.na(library) | library == "", 1, all)), ]

    ## Shuffle library sample names and split into folds
    fold_list <- nb_build_model_cv_split(library = library, folds = folds)
    folds <- length(fold_list)

    ## Create cluster
    cl <- nb_build_model_create_cluster(parallel_cores = parallel_cores)

    with_progress({
        p <- progressor(along = seq_along(fold_list))

        ## Perform parallelized N-fold cross validation
        results <- foreach(
            kFold = seq_along(fold_list),
            .verbose = FALSE,
            .packages = c("data.table", "igraph", "batl"),
            .inorder = TRUE) %dopar% {

            ## Counter to populate return output data table lists
            idx <- 0

            ## Initialize cross validation output lists
            list_2 <- nb_build_model_init_cv_output(
                fcombinations = fcombinations)
            model_fcombinations <- list_2$model_fcombinations
            all_assignments <- list_2$all_assignments

            ## Create training and testing sets from folds
            list_2 <- nb_build_model_get_folds(
                fold_list = fold_list,
                kFold = kFold,
                fcombinations = fcombinations,
                library = library)
            training <- list_2$training
            testing <- list_2$testing
            rm(list_2)

            ## Loop over all feature combinations
            for (kLength in seq_along(fcombinations)) {
                for (kCombo in seq_along(fcombinations[[kLength]])) {

                    ## Counter for populating return list
                    idx <- idx + 1

                    ## Rename barcode because decision functions return a column
                    ## named barcode too
                    setnames(testing, "Barcode", "Barcode_true")

                    ## Run naive Bayes
                    list_2 <- nb_build_model_nb(
                        testing = testing,
                        training = training,
                        features = fcombinations[[kLength]][[kCombo]],
                        decision = decision,
                        tolerance = tolerance,
                        transition_cutoff = NA,
                        pseudocount = pseudocount)

                    feature_log <- list_2$feature_log
                    output <- list_2$return

                    ## Get posterior probability cutoffs
                    transition_cutoff <- nb_build_model_estimate_cutoff(
                        output = output)

                    ## Run naive Bayes again with cutoffs
                    list_2 <- nb_build_model_nb(
                        testing = testing,
                        training = training,
                        features = fcombinations[[kLength]][[kCombo]],
                        decision = decision,
                        tolerance = tolerance,
                        transition_cutoff = transition_cutoff, # use cutoff
                        pseudocount = pseudocount)
                    output <- list_2$return

                    ## Rename barcode back to original name
                    setnames(testing, "Barcode_true", "Barcode")

                    ## Fill data table of model parameters
                    current_model <- nb_build_model_extract(
                        output = output,
                        transition_cutoff = transition_cutoff)

                    ## Save model to list
                    current_model[, "Fold" := kFold]
                    model_fcombinations[[idx]] <- current_model

                    ## Name list with feature combination used
                    names(model_fcombinations)[idx] <- paste(
                        fcombinations[[kLength]][[kCombo]], collapse = "_")

                    ## Fill data table of all assignments
                    output[, "Fold" := kFold]
                    output[, "Data" := "Training"]
                    all_assignments[[idx]] <- output

                    ## Name list with feature combination used
                    names(all_assignments)[idx] <- paste(
                        fcombinations[[kLength]][[kCombo]],
                        collapse = "_")

                    ## Progress bar:
                    p(sprintf(
                        "Fold=%g. Combination=%g/%g",
                        kFold, idx, sum(lengths(fcombinations))))
                }
            }

            if (full_output == FALSE) {
                rm(all_assignments)
                gc()
                all_assignments <- NA
            }

            return(list(
                model = model_fcombinations,
                assignments = all_assignments))
        }
    })

    ## Stop cluster
    stopCluster(cl)

    ## Unlist output and combine across folds
    all <- nb_build_model_unlist_results(
        results = results, full_output = full_output)
    output <- all$output
    all <- all$all

    ## Find smallest posterior by transition per feature combination
    smallest_posterior_cutoff <- vector("list", length = length(output))
    for (kComb in seq_along(smallest_posterior_cutoff)) {
        smallest_posterior_cutoff[[kComb]] <- nb_build_model_full_cutoff(
            output_idx = output[[kComb]])
        smallest_posterior_cutoff[[kComb]] <- unique(
            smallest_posterior_cutoff[[kComb]])
    }

    ## Rough end time
    function_end <- Sys.time()

    ## Generate naive Bayes model parameters/priors with the full dataset
    ## and append cutoffs and meta information in a separate list
    model_full <- vector("list", length = length(output))
    idx <- 0
    for (kLength in seq_along(fcombinations)) {
        for (kCombo in seq_along(fcombinations[[kLength]])) {

            ## Counter and 2-element list to hold model and meta information
            idx <- idx + 1
            temp <- vector("list", length = 2)

            ## Model
            list_2 <- nb_build_model_full(
                library = library,
                pseudocount = pseudocount,
                features = fcombinations[[kLength]][[kCombo]],
                cutoff = smallest_posterior_cutoff[[idx]])
            temp[[1]] <- list_2$likelihood
            log_vec <- list_2$feature_log
            names(temp)[1] <- "Model"

            ## Meta information
            meta_vec <- nb_build_model_meta(
                features = fcombinations[[kLength]][[kCombo]],
                decision = decision,
                library = library,
                function_start = function_start,
                function_end = function_end,
                folds = folds,
                exhaustive = exhaustive,
                tolerance = tolerance,
                parallel_cores = parallel_cores,
                full_output = full_output,
                pseudocount = pseudocount,
                log_vec = log_vec)
            temp[[2]] <- meta_vec
            names(temp)[2] <- "Meta_information"

            ## Combine and save into main output list
            model_full[[idx]] <- temp
            names(model_full)[idx] <- paste(
                fcombinations[[kLength]][[kCombo]],
                collapse = "_")
        }
    }

    if (full_output == TRUE) {
        return(list(
            model = model_full,
            models_cv = output,
            model_assignments = all))
    } else {
        return(list(model = model_full))
    }
}
