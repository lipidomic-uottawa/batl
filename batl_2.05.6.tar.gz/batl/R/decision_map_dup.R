#' decision_map_dup
#'
#' @description Maximum a posteriori decision algorithm. Assigns a label based
#' on the greatest observed posterior probability. There are no constraints
#' such that the same lipid label is assigned more than once per sample run.
#'
#' @usage
#' decision_map_dup(return)
#'
#' @param return Data table object of candidate assignments.
#'
#' @return
#' Boolean column indicating TRUE or FALSE lipid label assignments.
#'
#' @importFrom data.table setkey
#'
#' @keywords internal

decision_map_dup <- function(return) {

    ## Null strategy to pass R CMD check
    Index <- Barcode <- Posterior <- MAP_dup <- NULL

    return[, "MAP_dup" := NA]
    return[
        !(is.na(Posterior))
        , MAP_dup := ifelse(
            Posterior == max(Posterior, na.rm = TRUE), TRUE, FALSE)
        , by = c("Index", "Sample.Index", "Sample.Name")]

    return[!(is.na(Posterior)) & Posterior == 0, MAP_dup == FALSE]

    setkey(return, "Index", "Barcode")
    return(return)
}
